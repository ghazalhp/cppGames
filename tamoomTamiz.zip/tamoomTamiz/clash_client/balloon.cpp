//
// Created by ghazal on 6/27/16.
//

#include <iostream>
#include "balloon.h"

Balloon ::Balloon()  {
    cout<<"balloon"<<endl;
    name = "baloon";
    id = 1;
    hitSpeed = 3;
    deployTime = 1;
    range = 0;
    costEx = 5 ;
    hitPoints = 1050 ;
    damage = 600 ;
    life = hitPoints;
    whoAmI = new target(air);
    mySpeed = medium;
    myTargets = new vector<target* >;
    myTargets->push_back(new target (building));
    myType = troop;
    nameOfPicture = "2.png";
    picture = new QIcon("2.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);


}
void Balloon ::checkAlive() {
    if(!alive){
        cout<<"bomb daram misazam"<<endl;
        b = new Bomb();
        b->myPosition = this->myPosition;
        scene->addItem(b);
        b->setPos(myPosition.x , myPosition.y);
        b->prepareToMove(t,allHero,scene);
    }
}