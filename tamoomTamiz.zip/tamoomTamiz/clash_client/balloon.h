//
// Created by ghazal on 6/27/16.
//

#ifndef CLASH_CLIENT_BALLOON_H
#define CLASH_CLIENT_BALLOON_H

#include "hero.h"
#include "bomb.h"

class Balloon : public hero{
public:
    Balloon();
    virtual void checkAlive();
    Bomb * b ;
};

#endif //CLASH_CLIENT_BALLOON_H
