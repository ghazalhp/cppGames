//
// Created by ghazal on 7/20/16.
//


#include "bomb.h"
#include <iostream>
Bomb ::Bomb()  {
    cout<<"bomb"<<endl;
    myItem = new QGraphicsPixmapItem();

    name = "bomb";
    id = 17;
    hitSpeed = 1;
    deployTime = 1;
    range = 6;
    costEx = 1 ;
    hitPoints = 180;
    damage = 50 ;
    whoAmI = new target(building);
    life = hitPoints;
    mySpeed = fast;
    myTargets = new vector<target* >;
    myTargets->push_back(new target (building));
    myTargets->push_back(new target (air));
    myTargets->push_back(new target (ground));
    myType = spell;
    nameOfPicture = "bomb.jpg";
    picture = new QIcon("bomb.jpg");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(25, 25));
    setPixmap(*pixmap);
    cout<<"0"<<endl;


}
void Bomb ::prepareToMove(QTimer *timer1 , hero ** h , QGraphicsScene *s) {
    cout<<"prepare to mpve"<<name .toStdString() << endl;
    allHero = h ;
    scene = s ;
    //  t = timer ;;
    hitPointsButten = new QGraphicsTextItem();
    hitPointsButten->setDefaultTextColor(Qt :: black);
    QString x;
    x.setNum(500);
    hitPointsButten->setPlainText(x);
    hitPointsButten->setPos(this->pos().x()-18,this->pos().y()-18);

    addBomb();
}
void  Bomb ::addBomb() {
    cout<<"10"<<endl;
    t = new QTimer();
    t->start(500);
    connect(t, SIGNAL(timeout()), this, SLOT(explode()));
    cout<<"1"<<endl;
}
void Bomb ::explode() {
    cout<<"2"<<endl;
    for(int i = 0 ; i < scene->items().size();i++) {
        if (dynamic_cast<hero *>(scene->items().at(i)) != 0) {
            enemy = (hero *) scene->items().at(i);
            if ((range > 1 && sqrt((pow((myPosition.x - enemy->myPosition.x), 2) +
                                    (pow((myPosition.y - enemy->myPosition.y), 2)))) < range * 30)) {
                if (enemy->alive && scene->items().contains(enemy)) {
                    killEnemy();
                }
            }

        }
    }
    cout<<"3"<<endl;
    delete(pixmap);
    delete(this);

}
void Bomb ::killEnemy() {
    cout<<"enemy  "<< enemy->name.toStdString() << " " << enemy->myPosition.x << " "<<enemy->groupId << " me  " << name.toStdString()<<  " " << myPosition.x<< " " << groupId<<endl;
    if(enemy == this)
        cout<<"ajab"<<endl;
    enemy->hitPoints -= this->damage;
    if(enemy->hitPoints <=0 ){
        enemy->alive = false ;
        enemy->checkAlive();
        if(scene->items().contains(enemy))
            scene->removeItem(enemy);
        if(scene->items().contains(enemy->hitPointsButten))
            scene->removeItem(enemy->hitPointsButten);
        enemy = NULL;
    }
}