//
// Created by ghazal on 7/20/16.
//

#ifndef CLASH_CLIENT_BOMB_H
#define CLASH_CLIENT_BOMB_H
#include "hero.h"

class Bomb : public hero{
Q_OBJECT
public:
    Bomb();
    QTimer * t ;
    void addBomb();
    virtual void prepareToMove(QTimer *timer  ,hero ** h ,QGraphicsScene *s);
    virtual  void killEnemy();
public slots:
    void explode();



};
#endif //CLASH_CLIENT_BOMB_H
