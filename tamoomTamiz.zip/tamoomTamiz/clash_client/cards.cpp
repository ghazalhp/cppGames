#include <QtWidgets/QLabel>
#include <iostream>
#include "cards.h"
#include <erors.h>

//
// Created by ghazal on 6/26/16.
//
cards ::cards() {

    listOfCards = new vector<int>();
    allHero = new hero[15];
    board();
}
void cards ::moreOrLess(int x) {
    cout<<"raftam"<<endl;
    if(x > -1)
       listOfCards->pop_back();
    eror e;
    e.cardsChooseEror();
    if(x == 0)
        card->setStyleSheet(" QPushButton{ background-color : black; color : Yellow; }");
    if(x == 1)
        card1->setStyleSheet(" QPushButton{ background-color : black; color : Yellow; }");
    if(x == 2)
        card2->setStyleSheet(" QPushButton{ background-color : black; color : Yellow; }");
    if(x == 3)
        card3->setStyleSheet(" QPushButton{ background-color : black; color : Yellow; }");
    if(x == 4)
        card4->setStyleSheet(" QPushButton{ background-color : black; color : Yellow; }");
    if(x == 5)
        card5->setStyleSheet(" QPushButton{ background-color : black; color : Yellow; }");
    if(x == 6)
        card6->setStyleSheet(" QPushButton{ background-color : black; color : Yellow; }");
    if(x == 7)
        card7->setStyleSheet(" QPushButton{ background-color : black; color : Yellow; }");
    if(x == 8)
        card8->setStyleSheet(" QPushButton{ background-color : black; color : Yellow; }");
    if(x == 9)
        card9->setStyleSheet(" QPushButton{ background-color : black; color : Yellow; }");
    if(x == 10)
        card10->setStyleSheet(" QPushButton{ background-color : black; color : Yellow; }");
    if(x == 11)
        card11->setStyleSheet(" QPushButton{ background-color : black; color : Yellow; }");
    if(x == 12)
        card12->setStyleSheet(" QPushButton{ background-color : black; color : Yellow; }");
    if(x == 13)
        card13->setStyleSheet(" QPushButton{ background-color : black; color : Yellow; }");
    if(x == 14)
        card14->setStyleSheet(" QPushButton{ background-color : black; color : Yellow; }");





}
void cards ::chosen() {
    listOfCards->push_back(0);
    card->setStyleSheet(" QPushButton{ background-color : black; color : Red; }");
    if(listOfCards->size() > 8)
        moreOrLess(0);
}
void cards ::chosen1() {
    listOfCards->push_back(1);
    card1->setStyleSheet(" QPushButton{ background-color : black; color : Red; }");
    if(listOfCards->size() > 8)
        moreOrLess(1);
}
void cards ::chosen2() {
    listOfCards->push_back(2);
    card2->setStyleSheet(" QPushButton{ background-color : black; color : Red; }");
    if(listOfCards->size() > 8)
        moreOrLess(2);
}
void cards ::chosen3() {
    listOfCards->push_back(3);
    card3->setStyleSheet(" QPushButton{ background-color : black; color : Red; }");
    if(listOfCards->size() > 8)
        moreOrLess(3);
}
void cards ::chosen4() {
    listOfCards->push_back(4);
    card4->setStyleSheet(" QPushButton{ background-color : black; color : Red; }");
    if(listOfCards->size() > 8)
        moreOrLess(4);
}
void cards ::chosen5() {
    listOfCards->push_back(5);
    card5->setStyleSheet(" QPushButton{ background-color : black; color : Red; }");
    if(listOfCards->size() > 8)
        moreOrLess(5);
}
void cards ::chosen6() {
    listOfCards->push_back(6);
    card6->setStyleSheet(" QPushButton{ background-color : black; color : Red; }");
    if(listOfCards->size() > 8)
        moreOrLess(6);
}
void cards ::chosen7() {
    listOfCards->push_back(7);
    card7->setStyleSheet(" QPushButton{ background-color : black; color : Red; }");
    if(listOfCards->size() > 8)
        moreOrLess(7);
}
void cards ::chosen8() {
    listOfCards->push_back(8);
    card8->setStyleSheet(" QPushButton{ background-color : black; color : Red; }");
    if(listOfCards->size() > 8)
        moreOrLess(8);
}
void cards ::chosen9() {
    listOfCards->push_back(9);
    card9->setStyleSheet(" QPushButton{ background-color : black; color : Red; }");
    if(listOfCards->size() > 8)
        moreOrLess(9);
}
void cards ::chosen10() {
    listOfCards->push_back(10);
    card10->setStyleSheet(" QPushButton{ background-color : black; color : Red; }");
    if(listOfCards->size() > 8)
        moreOrLess(10);
}
void cards ::chosen11() {
    listOfCards->push_back(11);
    card11->setStyleSheet(" QPushButton{ background-color : black; color : Red; }");
    if(listOfCards->size() > 8)
        moreOrLess(11);
}
void cards ::chosen12() {
    listOfCards->push_back(12);
    card12->setStyleSheet(" QPushButton{ background-color : black; color : Red; }");
    if(listOfCards->size() > 8)
        moreOrLess(12);
}
void cards ::chosen13() {
    listOfCards->push_back(13);
    card13->setStyleSheet(" QPushButton{ background-color : black; color : Red; }");
    if(listOfCards->size() > 8)
        moreOrLess(13);
}
void cards ::chosen14() {
    listOfCards->push_back(14);
    card14->setStyleSheet(" QPushButton{ background-color : black; color : Red; }");
    if(listOfCards->size() > 8)
        moreOrLess(14);
}

void cards ::board() {
    cout<<"board";
    setFixedSize(1000, 700);
    setGeometry(600,0,1000,700);
    QPalette color(palette());
    color.setColor(QPalette::Background,Qt::black);
    setAutoFillBackground(true);
    setPalette(color);
    QLabel *bac = new QLabel(this);
    bac->setPixmap(QPixmap("cards.jpg"));
    bac->setAlignment(Qt:: AlignCenter);
    bac->setAttribute(Qt::WA_TranslucentBackground);
    bac->setGeometry(0,0,1000,700);
    QFont f("serif");
    f.setItalic(true);
    f.setPointSize(11);
    f.setBold(true);

    start = new QPushButton("back to menu", this);
    start->setGeometry(450,600,200,50);
    start->setFont(f);
    start->setStyleSheet(" QPushButton{ color : DarkBlue; }");


    card = new QPushButton("lava-hound", this);
    card->setGeometry(890-180,20,120,120);
    card->setFlat(true);
    card->setFont(f);
    card->setStyleSheet(" QPushButton{ background-color : black; color : yellow; }");
    connect(card, SIGNAL(clicked()), this, SLOT(chosen()));

    card1 = new QPushButton("balloon", this);
    card1->setGeometry(780-180,20,120,120);
    card1->setFlat(true);
    card1->setFont(f);
    card1->setStyleSheet(" QPushButton{ background-color : black; color : yellow; }");
    connect(card1, SIGNAL(clicked()), this, SLOT(chosen1()));


    card2 = new QPushButton("minion-horde", this);
    card2->setGeometry(670-180,20,120,120);
    card2->setFlat(true);
    card2->setFont(f);
    card2->setStyleSheet(" QPushButton{ background-color : black; color : yellow; }");
    connect(card2, SIGNAL(clicked()), this, SLOT(chosen2()));


    card3 = new QPushButton( "ice-wizard",this);
    card3->setGeometry(560-180,20,120,120);
    card3->setFlat(true);
    card3->setFont(f);
    card3->setStyleSheet(" QPushButton{ background-color : black; color : yellow; }");
    connect(card3, SIGNAL(clicked()), this, SLOT(chosen3()));


    card4 = new QPushButton("dark-prince", this);
    card4->setGeometry(450-180,20,120,120);
    card4->setFlat(true);
    card4->setFont(f);
    card4->setStyleSheet(" QPushButton{ background-color : black; color : yellow; }");
    connect(card4, SIGNAL(clicked()), this, SLOT(chosen4()));

    card5 = new QPushButton("miner", this);
    card5->setGeometry(890-180,150+20,120,120);
    card5->setFlat(true);
    card5->setFont(f);
    card5->setStyleSheet(" QPushButton{ background-color : black; color : yellow; }");
    connect(card5, SIGNAL(clicked()), this, SLOT(chosen5()));


    card6 = new QPushButton("valkyrie", this);
    card6->setGeometry(780-180,150+20,120,120);
    card6->setFlat(true);
    card6->setFont(f);
    card6->setStyleSheet(" QPushButton{ background-color : black; color : yellow; }");
    connect(card6, SIGNAL(clicked()), this, SLOT(chosen6()));


    card7 = new QPushButton("witch", this);
    card7->setGeometry(670-180,150+20,120,120);
    card7->setFlat(true);
    card7->setFont(f);
    card7->setStyleSheet(" QPushButton{ background-color : black; color : yellow; }");
    connect(card7, SIGNAL(clicked()), this, SLOT(chosen7()));

    card8 = new QPushButton("royal-giant", this);
    card8->setGeometry(560-180,150+20,120,120);
    card8->setFlat(true);
    card8->setFont(f);
    card8->setStyleSheet(" QPushButton{ background-color : black; color : yellow; }");
    connect(card8, SIGNAL(clicked()), this, SLOT(chosen8()));

    card9 = new QPushButton("hog-rider", this);
    card9->setGeometry(450-180,150+20,120,120);
    card9->setFlat(true);
    card9->setFont(f);
    card9->setStyleSheet(" QPushButton{ background-color : black; color : yellow; }");
    connect(card9, SIGNAL(clicked()), this, SLOT(chosen9()));


    card10 = new QPushButton("mirror", this);
    card10->setGeometry(890-180,280+40,120,120);
    card10->setFlat(true);
    card10->setFont(f);
    card10->setStyleSheet(" QPushButton{ background-color : black; color : yellow; }");
    connect(card10, SIGNAL(clicked()), this, SLOT(chosen10()));


    card11 = new QPushButton("zap", this);
    card11->setGeometry(780-180,280+40,120,120);
    card11->setFlat(true);
    card11->setFont(f);
    card11->setStyleSheet(" QPushButton{ background-color : black; color : yellow; }");
    connect(card11, SIGNAL(clicked()), this, SLOT(chosen11()));


    card12 = new QPushButton("rage", this);
    card12->setGeometry(670-180,280+40,120,120);
    card12->setFlat(true);
    card12->setFont(f);
    card12->setStyleSheet(" QPushButton{ background-color : black; color : yellow; }");
    connect(card12, SIGNAL(clicked()), this, SLOT(chosen12()));

    card13 = new QPushButton("furnace", this);
    card13->setGeometry(560-180,280+40,120,120);
    card13->setFlat(true);
    card13->setFont(f);
    card13->setStyleSheet(" QPushButton{ background-color : black; color : yellow; }");
    connect(card13, SIGNAL(clicked()), this, SLOT(chosen13()));


    card14 = new QPushButton("inferno-tower", this);
    card14->setGeometry(450-180,280+40,120,120);
    card14->setFlat(true);
    card14->setFont(f);
    card14->setStyleSheet(" QPushButton{ background-color : black; color : yellow; }");
    connect(card14, SIGNAL(clicked()), this, SLOT(chosen14()));
}
