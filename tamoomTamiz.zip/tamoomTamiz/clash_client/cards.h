//
// Created by ghazal on 6/26/16.
//

#include <QtWidgets/QWidget>
#include <QtWidgets/QPushButton>
#include "hero.h"
#include <vector>
#ifndef CLASH_CLIENT_CARDS_H
#define CLASH_CLIENT_CARDS_H
using  namespace std;
class cards :public QWidget{
    Q_OBJECT
public :
    QPushButton *card;
    QPushButton *card1;
    QPushButton *card2;
    QPushButton *card3;
    QPushButton *card4;
    QPushButton *card5;
    QPushButton *card6;
    QPushButton *card7;
    QPushButton *card8;
    QPushButton *card9;
    QPushButton *card10;
    QPushButton *card11;
    QPushButton *card12;
    QPushButton *card13;
    QPushButton *card14;


    vector<int> *listOfCards ;
    cards();
    void board();
    QPushButton *start ;

    hero * allHero;
    void moreOrLess(int x);
public slots:
    void chosen();
    void chosen1();
    void chosen2();
    void chosen3();
    void chosen4();
    void chosen5();
    void chosen6();
    void chosen7();
    void chosen8();
    void chosen9();
    void chosen10();
    void chosen11();
    void chosen12();
    void chosen13();
    void chosen14();



};
#endif //CLASH_CLIENT_CARDS_H
