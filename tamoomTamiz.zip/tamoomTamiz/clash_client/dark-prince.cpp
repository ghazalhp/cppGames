//
// Created by ghazal on 6/27/16.
//

#include "dark-prince.h"

DarkPrince ::DarkPrince()  {
    name = "dark-prince";
    id = 4;
    hitSpeed = 1.5;
    deployTime = 1;
    range = 0;
    costEx = 4 ;
    hitPoints = 700 ;
    damage = 135;
    whoAmI = new target(ground);
    life = hitPoints;
    mySpeed = medium;
    myTargets = new vector<target* >;
    myTargets->push_back(new target (ground));
    myTargets->push_back(new target (building));
    myType = troop;
    nameOfPicture = "5.png";
    picture = new QIcon("5.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);

}
