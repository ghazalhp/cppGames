//
// Created by ghazal on 6/27/16.
//

#ifndef CLASH_CLIENT_DARK_PRINCE_H
#define CLASH_CLIENT_DARK_PRINCE_H

#include "hero.h"

class DarkPrince : public hero{
public:
    DarkPrince();

};

#endif //CLASH_CLIENT_DARK_PRINCE_H
