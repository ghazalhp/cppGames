//
// Created by ghazal on 6/29/16.
//

#include <iostream>
#include "erors.h"
using namespace std;
eror ::eror() {
   cout<< "eror";
}
void eror ::cardsChooseEror() {
    QMessageBox msgBox;
    msgBox.setText("you have to choose 8 cards");
    msgBox.setGeometry(500,300,500,500);
    msgBox.exec();
}
void eror ::didntChooseEror() {
    QMessageBox msgBox;
    msgBox.setText(" you didnt select your hero you have to choose 8 cards");
    msgBox.setGeometry(500,300,500,500);
    msgBox.exec();
}