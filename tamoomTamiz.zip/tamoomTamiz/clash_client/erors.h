//
// Created by ghazal on 6/29/16.
//

#include <QtWidgets/QWidget>
#include <QtWidgets/QMessageBox>

#ifndef CLASH_CLIENT_ERORS_H
#define CLASH_CLIENT_ERORS_H
class eror   {

public:
    eror();
    void  cardsChooseEror();
    void  didntChooseEror();
};
#endif //CLASH_CLIENT_ERORS_H
