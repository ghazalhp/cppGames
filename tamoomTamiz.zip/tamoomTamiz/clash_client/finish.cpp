#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include "finish.h"

//
// Created by ghazal on 7/17/16.
//
Finish ::Finish(QString n) {
    finishBoard(n);
}
void Finish ::finishBoard(QString n) {
    setFixedSize(1000,700);
    setGeometry(600,0,1000,700);
    QPalette color(palette());
    color.setColor(QPalette::Background,Qt::black);
    setAutoFillBackground(true);
    setPalette(color);
    QLabel *picture = new QLabel(this);
    picture->setStyleSheet(" QLabel{ background-color : yellow; color : yellow; }");
    picture->setPixmap(QPixmap("menu.jpg"));
    picture->setGeometry(0,0,1000,700);
    picture->setAlignment(Qt::AlignCenter);
    picture->setAttribute(Qt::WA_TranslucentBackground);
    QFont f("serif");
    f.setItalic(true);
    f.setPointSize(45);
    f.setBold(true);
    QPushButton *finish = new QPushButton("the winner is :  " + n , this);
    finish->setFont(f);
    finish->setGeometry(0,200,900,300);
    finish->setStyleSheet(" QPushButton{  color : Red; }");
    finish->setFlat(true);
    QPushButton *finish2 = new QPushButton("exit" , this);
    finish2->setGeometry(400,550,200,100);
    finish2->setFont(f);
    finish2->setStyleSheet(" QPushButton{  color : yellow; }");
    finish2->setFlat(true);
    connect(finish2, SIGNAL(clicked()), this, SLOT(finishGame()));

}
void Finish ::finishGame() {
  //  exit(0);

}
