//
// Created by ghazal on 7/17/16.
//

#ifndef CLASH_CLIENT_FINISH_H
#define CLASH_CLIENT_FINISH_H

#include <QtWidgets/QWidget>

class Finish : public  QWidget{
Q_OBJECT
public:
    Finish(QString n);
   void  finishBoard(QString name);
public slots:
    void finishGame();
};
#endif //CLASH_CLIENT_FINISH_H
