//
// Created by ghazal on 7/22/16.
//



//
// Created by ghazal on 6/27/16.
//

#include <iostream>
#include "fire-spirit.h"

FireSpirit::FireSpirit()  {
    cout<<"fire - spirit"<<endl;
    myItem = new QGraphicsPixmapItem();

    name = "Fire-Spirit";
    id = 19;
    hitSpeed = 1;
    deployTime = 1;
    range = 2;
    costEx = 1 ;
    hitPoints = 30;
    damage = 30 ;
    whoAmI = new target(ground);
    life = hitPoints;
    mySpeed = fast;
    myTargets = new vector<target* >;
    myTargets->push_back(new target (building));
    myTargets->push_back(new target (air));
    myTargets->push_back(new target (ground));
    myType = troop;
    nameOfPicture = "fs.jpg";
    picture = new QIcon("fs.jpg");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);





}
