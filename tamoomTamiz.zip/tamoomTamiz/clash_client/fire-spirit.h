//
// Created by ghazal on 7/22/16.
//

#ifndef CLASH_CLIENT_FIRE_SPIRIT_H
#define CLASH_CLIENT_FIRE_SPIRIT_H

#include "hero.h"

class FireSpirit : public hero {
public:
    FireSpirit();
};
#endif //CLASH_CLIENT_FIRE_SPIRIT_H
