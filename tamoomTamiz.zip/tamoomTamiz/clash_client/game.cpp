//
// Created by ghazal on 6/30/16.
//


#include <iostream>
#include "game.h"
#include "lava-hound.h"
#include "balloon.h"
#include "minion-horde.h"
#include "ice-wizard.h"
#include "dark-prince.h"
#include "miner.h"
#include "valkyrie.h"
#include "royal-giant.h"
#include "hog-rider.h"
#include "mirror.h"
#include "zap.h"
#include "rage.h"
#include "using-furnace.h"
#include "inferno-tower.h"
#include "king.h"
#include "queen.h"
#include "gun.h"
#include "grass.h"
#include "finish.h"
#include <QScrollBar>
#include <QtWidgets>
#include <witch.h>


using namespace std;
game::game(vector<int> *a,QString n, QString ip ,QString sIP , bool mode ){
    cout<<"game"<<endl;
   this->a = a ;
    this ->mode = mode ;
    cout << "mode game " << mode << endl;
    vector<int> *b = new vector<int>;
    if(mode) {
        myHero = new hero *[11];
        enemy = new hero *[11];


    }
    else{
        myHero = new hero *[13];
        enemy = new hero *[13];

    }
    for(int i = 0 ; i < 8 ; i++){
        b->push_back(i);
    }

    this->b = b;
    setHeros(b,enemy , 0 );
    enemyCards = new int [5];
    cards = new vector<QPushButton * >;
    heroOfCards = new vector<int>;


    elxirNum = 5 ;
    aiElxir = 5 ;
    time = 0 ;
    if(mode)
        finishTime =3*60*1000;
    else
        finishTime = 5 * 60 *1000;
    timer = new QTimer();
    connect(timer, SIGNAL(timeout()), this, SLOT(setElxir()));
    timer->start(20);
    setHeros(a ,myHero , 1);
    gameBoard();
    cout<<"game board tamoom shod"<<endl;
    cardBoard();
    elxirBoard();
    towerBoard(myHero , 0);

    towerBoard(enemy , 1);
    cout<<"tower board finish"<<endl;
    serverIP = sIP;
    mySocket = new QTcpSocket();
    IP = ip ;
    user_name = n ;
    if(!mode) {
        mySocket = new QTcpSocket();
        prepareToConnect();
    }

    cout<<"game() finish"<<endl;

}

void game ::towerBoard(hero ** myHero , int i) {
    cout<<"tower board"<<endl;
    myHero[8]->setPos(380,520);
    myHero[8]->myPosition.x = 380;
    myHero[8]->myPosition.y = 520;
    myHero[8]->alive = true;
    cout<<"1"<<endl;
    if(i != 1)
        myHero[8]->prepareToMove(timer,this->enemy,scene);
    scene->addItem(myHero[8]);

    myHero[9]->setPos(680,410);
    myHero[9]->myPosition.x = 680;
    myHero[9]->myPosition.y = 410;
    myHero[9]->alive = true;
    if(i != 1)
        myHero[9]->prepareToMove(timer,this->enemy,scene);
    scene->addItem(myHero[9]);

    myHero[10]->setPos(80,410);
    myHero[10]->myPosition.x = 80;
    myHero[10]->myPosition.y = 410;
    if(i != 1)
        myHero[10]->prepareToMove(timer,this->enemy,scene);
    myHero[10]->alive = true;
    scene->addItem(myHero[10]);
    if(i == 1){
        myHero[8]->prepareToMove(timer,this->myHero,scene);
        myHero[9]->prepareToMove(timer,this ->myHero,scene);
        myHero[10]->prepareToMove(timer,this->myHero,scene);
        myHero[8]->setPos(380,80);
        myHero[8]->myPosition.y = 80;
        myHero[9]->setPos(680,170);
        myHero[9]->myPosition.y = 170;
        myHero[10]->setPos(80,170);
        myHero[10]->myPosition.y = 170;
    }
    if(!mode){
        if(i == 1){
            myHero[11]->setPos(230,90);
            myHero[11]->myPosition.y = 90;

            myHero[12]->setPos(530,90);
            myHero[12]->myPosition.y = 90;
            myHero[11]->alive = true;
            myHero[12]->alive = true;
            scene->addItem(myHero[11]);
            scene->addItem(myHero[12]);
            myHero[11]->prepareToMove(timer,this->myHero,scene);
            myHero[12]->prepareToMove(timer,this->myHero,scene);
        }
        else {
            myHero[11]->setPos(230, 490);
            myHero[11]->myPosition.x = 230;
            myHero[11]->myPosition.y = 490;
            myHero[12]->setPos(530, 490);
            myHero[12]->myPosition.x = 530;
            myHero[12]->myPosition.y = 490;
            myHero[11]->alive = true;
            myHero[12]->alive = true;
            scene->addItem(myHero[11]);
            scene->addItem(myHero[12]);
            myHero[11]->prepareToMove(timer, this->enemy, scene);
            myHero[12]->prepareToMove(timer, this->enemy, scene);

        }

    }


}
void game  ::setHeros(vector<int> *a , hero** myHero , int j) {
    cout<<"setHero"<<a->size()<< " "<< a->operator[](5)<< endl;
    myHero[8] = new King();
    myHero[9] = new Queen();
    myHero[10] = new Queen();
    if(!mode){
        myHero[11] = new Queen();
        myHero[12] = new Queen();
    }
    if(mode || myHero == this->myHero) {
        for (int i = 0; i < a->size(); i++) {

            if (a->operator[](i) == 0) {
                myHero[i] = new LavaHound();
            }
            if (a->operator[](i) == 1) {
                myHero[i] = new Balloon();
            }
            if (a->operator[](i) == 2) {
                myHero[i] = new MinionHorde();
            }
            if (a->operator[](i) == 3) {
                myHero[i] = new IceWizard();
            }
            if (a->operator[](i) == 4) {
                myHero[i] = new DarkPrince();
            }
            if (a->operator[](i) == 5) {
                myHero[i] = new Miner();
            }
            if (a->operator[](i) == 6) {
                myHero[i] = new Valkyrie();
            }
            if (a->operator[](i) == 7) {
                myHero[i] = new Witch();
            }
            if (a->operator[](i) == 8) {
                myHero[i] = new RoyalGiant();
            }
            if (a->operator[](i) == 9) {
                myHero[i] = new HogRider();
            }
            if (a->operator[](i) == 10) {
                myHero[i] = new Mirror();
            }
            if (a->operator[](i) == 11) {
                myHero[i] = new Zap();
            }
            if (a->operator[](i) == 12) {
                myHero[i] = new Rage();
            }
            if (a->operator[](i) == 13) {
                myHero[i] = new Furnace();
            }
            if (a->operator[](i) == 14) {
                myHero[i] = new Inferno();
            }

        }
    }
    if(!mode){
        for(int i = 0 ; i < 13 ; i ++ ) {
            if(i < 8)
                this->enemy[i] = new hero();
            this->enemy[i]->mode = false;
            this->enemy[i]->groupId = 1 ;
        }
        if(j == 1)
        for(int i = 0 ; i < 13; i ++ ) {
            this->myHero[i]->mode = false;
            this->myHero[i]->groupId = 0 ;
        }
    }
    else{
        for(int i = 0 ; i < 11 ; i ++ ) {
            this->enemy[i]->groupId = 1 ;
        }
        if(j == 1)
            for(int i = 0 ; i < 11; i ++ ) {
                this->myHero[i]->groupId = 0 ;
            }
    }

  //  cout<<"enemy sakhtam"<<endl;

}
void game ::setElxir() {
  //  cout<<"ai elxir "<<aiElxir <<endl;
    time+=20;
    QString n;
    n.setNum((int)time/1000);
    timeButten->setText(n);

    if(time == finishTime){
        int x= 0 , y = 0   ;
        for(int i = 8 ; i < 11 ; i++) {
            if (myHero[i]->alive)
                x++;
            if(enemy[i]->alive)
                y++;
        }
        if(!mode)
        for(int i = 11 ; i < 13 ; i++) {
            if (myHero[i]->alive)
                x++;
            if(enemy[i]->alive)
                y++;
        }
        cout<<"finishhhhhhhh"<<x <<" "<<y << endl;
        if(x ==  y )
            finishTime+=60*1000;
        if(x < y)
            this ->myHero[8]->alive = false;
        if(y< x )
            this->enemy[8]->alive = false;
    }
    if(!(myHero[8]->alive) ) {
        pause();
        Finish *f = new Finish("pc");
        f->setGeometry(0 , 0 ,1000 , 700);
        scene->addWidget(f);
        return;
    }
    if(!(enemy[8]->alive)){

        pause();

        Finish *f = new Finish(user_name);
        f->setGeometry(0 , 0 ,1000 , 700);
        scene->addWidget(f);
        return;
    }
    if(elxirNum < 10) {
    //    cout << "exiiiiiiiiiir" << endl;
        elxirNum += 0.01;
        QString n;
        n.setNum((int)elxirNum);
        elxir->setText(n);
    }
    else {
        elxirNum = 10;;
    }
    if(aiElxir < 10) {
        aiElxir +=0.01;
    }
    else {
        aiElxir = 10 ;
    }
    openCards();
    if(mode)
        decide();
//    sendToServer();
}
void game ::decide() {
    int best = 0  , nesbat = 0;
    for(int i = 0 ; i < 4 ; i ++){
         int myNesbat = enemy[enemyCards[i]]->hitPoints + enemy[enemyCards[i]]->damage ;
            if(myNesbat > nesbat){
                best = i ;
                nesbat = myNesbat ;
            }
    }
    enemySwichCards(best);

}
void game ::openCards() {
    for(int i = 0 ; i <  4  ; i ++){
        if(myHero[heroOfCards->operator[](i)]->costEx < elxirNum)
            cards->operator[](i)->setDisabled(false);
        else
            cards->operator[](i)->setDisabled(true);


    }
}
void game::gameBoard() {
    cout<<"board"<<endl;
    setFixedSize(1000, 700);
    setGeometry(300,0,1000,700);
    scene = new QGraphicsScene();
    scene->setSceneRect(0, 0, 1000, 700);
    setAttribute(Qt::WA_TranslucentBackground);
    setAlignment(Qt::AlignCenter);
    verticalScrollBar()->blockSignals(true);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    horizontalScrollBar()->blockSignals(true);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setScene(scene);
    scene->setBackgroundBrush(Qt::cyan);

    Grass *grass = new Grass(this,1);
    grass->setPos(0,0);
    grass->acceptedMouseButtons();
    scene->addItem(grass);


    Grass *grass2 = new Grass(this,2);
    grass2->setPos(0,350);
    grass2->acceptedMouseButtons();
    scene->addItem(grass2);

    Grass *grass22 = new Grass(this,3);
    grass22->setPos(0,650);
    //grass2->acceptedMouseButtons();
    scene->addItem(grass22);


    QGraphicsPixmapItem *pol = new QGraphicsPixmapItem();
    QPixmap pixmap3 ;
  //  cout<<"image"<<endl;
    QImage *image3 = new QImage("pol.jpg");
   // cout<<"rad kardam"<<endl;
    pixmap3.convertFromImage(image3->scaled(50,60));
    pol->setPixmap(pixmap3);
    pol->setPos(200,295);
    scene->addItem(pol);
    pol->acceptedMouseButtons();
    QGraphicsPixmapItem *pol2 = new QGraphicsPixmapItem();
    QPixmap pixmap32 ;
  //  cout<<"image"<<endl;
    QImage *image32 = new QImage("pol.jpg");
 //   cout<<"rad kardam"<<endl;
    pixmap32.convertFromImage(image32->scaled(50,60));
    pol2->setPixmap(pixmap32);
    pol2->setPos(700,295);
    scene->addItem(pol2);
    pol2->acceptedMouseButtons();

    cout<<"inja "<<endl;


}
void game ::elxirBoard() {

        elxir = new QPushButton();
        elxir-> setStyleSheet(" QPushButton{ background-color : Black; color : yellow; }");
        //exir->operator[](i)->setText("1");
        elxir->setGeometry(910,660 , 40, 30);
        scene->addWidget(elxir);


    timeButten = new QPushButton();
    timeButten-> setStyleSheet(" QPushButton{ background-color : Black; color : yellow; }");
    //exir->operator[](i)->setText("1");
    timeButten->setGeometry(910,40 , 40, 30);
    scene->addWidget(timeButten);

}
void game::cardBoard() {
    cout<<"card board"<<endl;
    for(int i = 0 ; i < 5 ;i ++){
        QPushButton *x = new QPushButton();
        cards->push_back(x);
        cards->operator[](i)-> setStyleSheet(" QPushButton{ background-color : Green; color : yellow; }");
        heroOfCards->push_back(i);
        cards->operator[](i)->setDisabled(true);
        cout<<"3"<<endl;
        if(i<4) {
            cards->operator[](i)->setGeometry(10 + (120 * i), 620, 75, 75);
            cards->operator[](i)->setDisabled(true);
            if(i == 0)
                connect(cards->operator[](i), SIGNAL(clicked()), this, SLOT(switchCards()));
            if(i == 1)
                connect(cards->operator[](i), SIGNAL(clicked()), this, SLOT(switchCards1()));

            if(i == 2)
                connect(cards->operator[](i), SIGNAL(clicked()), this, SLOT(switchCards2()));

            if(i == 3)
                connect(cards->operator[](i), SIGNAL(clicked()), this, SLOT(switchCards3()));
            cout<<"4"<<endl;


        }
        else
            cards->operator[](i)->setGeometry(10+(120*i),620,75,75);
        cout<<"6"<<endl;
        cards->operator[](i)->setIcon(*(myHero[i]->picture));
        cards->operator[](i)->setIconSize(QSize(75,75));
        cards->operator[](i)->setFlat(true);

        scene->addWidget(cards->operator[](i));
        pointToCards = 4;
        cout<<"5"<<endl;
    }

    for(int i = 0 ; i < 5 ; i ++)
        enemyCards[i]= i ;
    pointToEnemyCards = 4 ;

    cout<<"2"<<endl;
    q= new QPushButton("Quit");
    q-> setStyleSheet(" QPushButton{ background-color : DarkOrange; color : Black; }");
    q->setGeometry(800,620,75,75);
    scene->addWidget(q);

    m= new QPushButton("mute");
    m-> setStyleSheet(" QPushButton{ background-color : cyan; color : Black; }");
    m->setGeometry(800-2*85,620,75,75);
    scene->addWidget(m);


    p = new QPushButton("Pause");
    p-> setStyleSheet(" QPushButton{ background-color : DarkRed; color : yellow; }");
    p->setGeometry(800-85,620,75,75);
    scene->addWidget(p);
    connect(p, SIGNAL(clicked()), this, SLOT(pause()));
    cout<<"end of card board"<<endl;
}
void game ::pause() {
    cout<<"pause"<<endl;
    pausePress++;
    if(pausePress % 2 == 1) {
        timer->stop();
        for(int i = 0 ; i<scene->items().size() ; i++){
            if(dynamic_cast<hero*>(scene->items().at(i))){
                hero * k = (hero *)scene->items().at(i);
                k->t->stop();
                k->dpt->stop();
            }

        }

    }
    else {
        timer->start();
        for(int i = 0 ; i<scene->items().size() ; i++){
            if(dynamic_cast<hero*>(scene->items().at(i))){
                hero * k = (hero *)scene->items().at(i);
                k->t->start(20);
                k->dpt->start(20);
            }

        }

    }
}
void game ::switchCards() {

//    cout << "bing" << endl;
    if(pointToCards == 7)
        pointToCards = -1 ;
  //  cout<<"point to cards"<<pointToCards<<endl;
    int i = 0;
    gotToBattle = myHero[heroOfCards->operator[](i)];
    if(dynamic_cast<Mirror * >(myHero[heroOfCards->operator[](i)]) == 0)
        beforForMiror = heroOfCards->operator[](i);
    elxirNum -= gotToBattle->costEx;
    cards->operator[](i)->setIcon(*(myHero[heroOfCards->operator[](4)]->picture));
    pointToCards++;
    cards->operator[](4)->setIcon(*(myHero[pointToCards]->picture));
    heroOfCards->operator[](i) =heroOfCards->operator[](4);
    heroOfCards->operator[](4) = pointToCards;



}
void game ::switchCards1() {
  //  cout << "bing" << endl;
    if(pointToCards == 7)
        pointToCards = -1 ;
  //  cout<<"point to cards"<<pointToCards<<endl;

    int i = 1;
    gotToBattle = myHero[heroOfCards->operator[](i)];
    if(dynamic_cast<Mirror * >(myHero[heroOfCards->operator[](i)]) == 0)
        beforForMiror = heroOfCards->operator[](i);
    elxirNum -= gotToBattle->costEx;
    cards->operator[](i)->setIcon(*(myHero[heroOfCards->operator[](4)]->picture));
    pointToCards++;
    cards->operator[](4)->setIcon(*(myHero[pointToCards]->picture));
    heroOfCards->operator[](i) =heroOfCards->operator[](4);
    heroOfCards->operator[](4) = pointToCards;


}
void game ::switchCards2() {
  //  cout << "bing" << endl;
    if(pointToCards == 7)
        pointToCards = -1 ;
  //  cout<<"point to cards"<<pointToCards<<endl;
    int i = 2;
    gotToBattle = myHero[heroOfCards->operator[](i)];
    if(dynamic_cast<Mirror * >(myHero[heroOfCards->operator[](i)]) == 0)
        beforForMiror = heroOfCards->operator[](i);
    elxirNum -= gotToBattle->costEx;
    cards->operator[](i)->setIcon(*(myHero[heroOfCards->operator[](4)]->picture));
    pointToCards++;
    cards->operator[](4)->setIcon(*(myHero[pointToCards]->picture));
    heroOfCards->operator[](i) =heroOfCards->operator[](4);
    heroOfCards->operator[](4) = pointToCards;



}
void game ::switchCards3() {
  //  cout << "bing" << endl;
    if(pointToCards == 7)
        pointToCards = -1 ;
   // cout<<"point to cards"<<pointToCards<<endl;
    int i = 3;

    gotToBattle = myHero[heroOfCards->operator[](i)];
    if(dynamic_cast<Mirror * >(myHero[heroOfCards->operator[](i)]) == 0)
        beforForMiror = heroOfCards->operator[](i);
    elxirNum -= gotToBattle->costEx;
    cards->operator[](i)->setIcon(*(myHero[heroOfCards->operator[](4)]->picture));
    pointToCards++;
    cards->operator[](4)->setIcon(*(myHero[pointToCards]->picture));
    heroOfCards->operator[](i) =heroOfCards->operator[](4);
    heroOfCards->operator[](4) = pointToCards;


}
void game ::enemySwichCards(int i) {
    if(pointToEnemyCards == 7)
        pointToEnemyCards = -1 ;
    if(enemy[enemyCards[i]]->costEx < aiElxir ){
        gotToBattle2 = enemy[enemyCards[i]];
        aiElxir-= gotToBattle2->costEx ;
        pointToEnemyCards++;
        enemyCards[i] = enemyCards[4];
        enemyCards[4] = pointToEnemyCards;
     //   cout<<"mmmmmmmmmmm"<<endl;
        setPosOfHero2(400,200,1);
    }
}

void game :: setPosOfHero(int x , int y , int grassId){

  //  coif(ut<<"here"<<endl;
    if(!dynamic_cast<Zap * >(gotToBattle) && !dynamic_cast<Rage * >(gotToBattle)  && !dynamic_cast<Miner * >(gotToBattle))
        if(grassId == 1)
            return;

    if(gotToBattle != 0  ) {
      //  cout<<"2222"<<endl;

        if(dynamic_cast<Mirror * >(gotToBattle) != 0){
            cout<<"aaaaa" << endl;
            gotToBattle = myHero[beforForMiror];

            cout<<"go To " << gotToBattle->name.toStdString()<<endl;
        }
        gotToBattle->lifeTime = 0 ;
        if (grassId < 3) {
            if (grassId == 1) {
                gotToBattle->setPos(x, y);
                gotToBattle->myPosition.x = x;
                gotToBattle->myPosition.y = y;
            }
            else {
                gotToBattle->setPos(x, y + 350);
                gotToBattle->myPosition.x = x;
                gotToBattle->myPosition.y = y + 350;
            }
            scene->addItem(gotToBattle);
            gotToBattle->hitPoints = gotToBattle->life;
            gotToBattle->alive = true;

            //QTimer *timer = new QTimer();
         //   cout << "setPosOfHEro" << endl;
            gotToBattle->prepareToMove(timer, enemy, scene);
            if(!mode)
                sendToServer();
            gotToBattle = NULL;

        }
    }
}

void game :: setPosOfHero2(int x , int y , int grassId){
    cout<<"hereeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeekn3k eNQJKNKLNLLLLLLLLLLLLLLNnnnnnnnnnnnnnnnnnnnn"<<endl;
    if(gotToBattle2 != 0) {
        cout<<"2222"<<endl;
        gotToBattle2->lifeTime = 0 ;
        if (grassId < 3) {
            if (grassId == 1) {
                gotToBattle2->setPos(x, y);
                gotToBattle2->myPosition.x = x;
                gotToBattle2->myPosition.y = y;
            }
            else {
                gotToBattle2->setPos(x, y + 350);
                gotToBattle2->myPosition.x = x;
                gotToBattle2->myPosition.y = y + 350;
            }
            scene->addItem(gotToBattle2);
            gotToBattle2->hitPoints = gotToBattle2->life;
            gotToBattle2->alive = true;
            //QTimer *timer = new QTimer();
            cout << "setPosOfHEro" << endl;
            gotToBattle2->prepareToMove(timer,myHero, scene);
            gotToBattle2 = NULL;


        }
    }
}
void game ::prepareToConnect() {
    cout << "prepare To Connec" << endl;
    mySocket->connectToHost(serverIP,3000);
    connect(mySocket,SIGNAL(readyRead()), this,SLOT(reciveFromServer()));

}

void game ::reciveFromServer() {
    cout<< " server be man pm dad" << endl;
    QString data = mySocket-> readAll();
    cout<<"ino gereftam "<<data.toStdString()<<endl;
    setEnemy(data);

}
void game ::setEnemy(QString sendEnemy) {
    QString x  ;
    int j = 0 ;
    for(int i = j ; i< sendEnemy.length() ; i++){
        if(sendEnemy[i]!= '/'){
            x+=sendEnemy[i];
        }
        else {
            j = i ;
            break;
        }

    }
    if(x!=user_name) {
        cout << "setEnemyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy" << j << endl;
        int id = 0;
        for (int i = j + 1; i < sendEnemy.length(); i++) {
            if (sendEnemy[i] != '/') {
                id *= 10;
                id += ((sendEnemy.toStdString()[i]) - '0');
            }
            else {
                j = i;
                break;
            }

        }
        int x2 = 0;
        cout << "j : " << j << endl;
        for (int i = j + 1; i < sendEnemy.length(); i++) {
            if (sendEnemy[i] != '/') {
                x2 *= 10;
                x2 += ((sendEnemy.toStdString()[i]) - '0');
            }
            else {
                j = i;
                break;
            }

        }
        cout << "x" << x2 << " j" << j << endl;
        int y2 = 0;
        for (int i = j+1; i < sendEnemy.length(); i++) {
            if (sendEnemy[i] != '/') {
                y2 *= 10;
                y2 += ((sendEnemy.toStdString()[i]) - '0');
            }
            else
                break;

        }
        cout << "y" << y2 << endl;
        fillGotoBattle(id);
        if(x[x.length()-1] != user_name[user_name.length()-1])
            y2=abs(y2-600);
        gotToBattle2->setPos(x2, y2);
        gotToBattle2->myPosition.x = x2 ;
        gotToBattle2->myPosition.y = y2 ;
        gotToBattle2->lifeTime = 0 ;
        scene->addItem(gotToBattle2);
        gotToBattle2->hitPoints = gotToBattle2->life;
        gotToBattle2->alive = true;
        //QTimer *timer = new QTimer();
        cout << "setPosOfHEro" << endl;
        if(x[x.length()-1] != user_name[user_name.length()-1]) {
            gotToBattle2->groupId = 1 ;
            gotToBattle2->prepareToMove(timer, myHero, scene);

            for(int j = 0 ; j < 13 ; j++){
                if(!(this->enemy[j]->alive)){
                    enemy[j] = gotToBattle2;
                    break;
                }
            }
        }
        else {
            gotToBattle2->groupId = 0 ;
            gotToBattle2->prepareToMove(timer, enemy, scene);
        }

    }

}

void game ::fillGotoBattle(int i) {
    if (i == 0) {
        gotToBattle2 = new LavaHound();
    }
    if (i== 1) {
        gotToBattle2 = new Balloon();
    }
    if (i == 2) {
        gotToBattle2 = new MinionHorde();
    }
    if (i == 3) {
        gotToBattle2 = new IceWizard();
    }
    if (i == 4) {
        gotToBattle2 = new DarkPrince();
    }
    if (i == 5) {
        gotToBattle2 = new Miner();
    }
    if (i == 6) {
        gotToBattle2 = new Valkyrie();
    }
    if (i == 7) {
        gotToBattle2 = new Witch();
    }
    if (i == 8) {
        gotToBattle2 = new RoyalGiant();
    }
    if (i == 9) {
        gotToBattle2 = new HogRider();
    }
    if (i == 10) {
        gotToBattle2 = new Mirror();
    }
    if (i == 11) {
        gotToBattle2 = new Zap();
    }
    if (i == 12) {
        gotToBattle2 = new Rage();
    }
    if (i == 13) {
        gotToBattle2 = new Furnace();
    }
    if (i == 14) {
        gotToBattle2 = new Inferno();
    }

    cout<<"fill this2" << gotToBattle2->name.toStdString() <<endl;
}
void game ::sendToServer() {

   //cout<<" send TO  server" << endl;

    string data;
    QString Q4 =user_name;
    data+=Q4.toStdString();
    data +="/";
    QString Q ;
    Q.setNum(gotToBattle->id);
    data+=Q.toStdString();
    cout<<"id"<<gotToBattle->id<<  " "  <<  data  << endl;
    data+="/";
    QString Q2 ;
    Q2.setNum(gotToBattle->myPosition.x);
    data+=Q2.toStdString();
    data+="/";
    QString Q23 ;
    cout<<"y asli"<< gotToBattle->myPosition.y<<endl;
    Q23.setNum(gotToBattle->myPosition.y);
    data+=Q23.toStdString();
    data+="/";
    
    cout<<"data"<<data<<endl;
    QByteArray dataToB = &data[0];
        mySocket->write(dataToB);

}
