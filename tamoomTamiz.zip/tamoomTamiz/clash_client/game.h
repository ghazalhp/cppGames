//
// Created by ghazal on 6/30/16.
//

#ifndef CLASH_CLIENT_GAME_H
#define CLASH_CLIENT_GAME_H

#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGraphicsPixmapItem>
#include <hero.h>
#include <vector>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QProgressBar>
#include <QtNetwork/QTcpSocket>



using namespace std;
class game : public QGraphicsView {
    Q_OBJECT
public:
    QGraphicsScene *scene;
    game(vector<int> *listOfCards,QString n, QString ip ,QString sIP , bool mode);
    bool mode ;
    void gameBoard();
    void elxirBoard();
   vector<QPushButton * > *cards ;
    vector<int> *heroOfCards ;
    int pointToCards;
    QPushButton  *elxir ;
    double elxirNum ;
    double  aiElxir;
    vector<int>* a ;
    vector<int>* b ;
    hero ** myHero ;
    hero ** enemy ;
    QTimer *timer ;
    void setHeros(vector<int> *listOfCards, hero**myHero , int i);
    void cardBoard();
    void towerBoard(hero **myHero, int i);
    void startHeroWorking(int i, int x , int y);
    QPushButton *p;
    QPushButton * q;
    QPushButton * m;
    void setPosOfHero(int x , int y , int grassID );
    void setPosOfHero2(int x , int y , int grassID );
    hero *gotToBattle = 0;
    void openCards();
    void decide();
    int pointToEnemyCards;
    int *enemyCards;
    hero *gotToBattle2 = 0;
    int beforForMiror ;
    int pausePress = 0 ;
    int time ;
    int finishTime ;
    QPushButton  *timeButten ;
    void enemySwichCards(int i );
    void fillGotoBattle(int i );
public slots:
    void switchCards();
    void switchCards1();
    void switchCards2();
    void switchCards3();
    void setElxir();
    void pause();

private:
    bool playNoti = false;

    QTcpSocket *mySocket ;
    QString IP ;
    QString serverIP ;
    QString user_name ;
    void setEnemy(QString enemy);
public slots :
    void sendToServer();
    void reciveFromServer();
    void  prepareToConnect();





};
#endif //CLASH_CLIENT_GAME_H
