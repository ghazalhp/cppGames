//
// Created by ghazal on 7/6/16.
//

#include <iostream>
#include "grass.h"
#include <QGraphicsSceneMouseEvent>
#include <QGraphicsItem>
Grass ::Grass(game * g, int id):g(g) , id(id)  {

  //  acceptedMouseButtons();
    pixmap = new QPixmap();
    image = new QImage("grass.jpg");
    pixmap->convertFromImage(image->scaled(1000, 300));
    setPixmap(*pixmap);

}
void Grass::mousePressEvent(QGraphicsSceneMouseEvent *event) {
     cout << "mouuuuse" << endl;
    if(g) {
        cout<<"11111"<<endl;
        g->setPosOfHero(event->pos().x(), event->pos().y(), id);
    }
}