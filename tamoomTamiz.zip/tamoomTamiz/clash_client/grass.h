//
// Created by ghazal on 7/6/16.
//

#ifndef CLASH_CLIENT_GRASS_H
#define CLASH_CLIENT_GRASS_H
#include <QtCore/QString>
#include <QtGui/QIcon>
#include <QtWidgets/QGraphicsPixmapItem>
#include <QTimer>
#include "game.h"

using namespace std;
class Grass: public QObject, public QGraphicsPixmapItem{

public:
    int id ;
    Grass(game *G , int id);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    QPixmap *pixmap ;
    QImage *image ;
    game *g ;


};
#endif //CLASH_CLIENT_GRASS_H
