//
// Created by ghazal on 7/4/16.
//

#include <QtWidgets>
#include <QtNetwork>
#include <QGraphicsItem>
#include <QTimer>
#include <gun.h>
#include <iostream>

using namespace std ;
Gun::Gun(QGraphicsItem* item, QTimer* timer,int fx,int fy,  int x , int y, double v ,QWidget *parent ) : QDialog(parent), timer(timer), item(item) , x(x) ,y(y),fx(fx),fy(fy),v(v){
  //  cout << "hereGun" << v << endl;
    t =  timer ;
    myPosition.x = fx;
    myPosition.y = fy ;
    t->start(70/v);
    connect(t, SIGNAL(timeout()), this, SLOT(f()));
}
void Gun ::setAim(int x, int y) {
    this-> x =  x;
    this->y = y ;
}
void Gun::f() {
    //cout<<"to f" << endl;
    if( sqrt((pow((myPosition.x - x), 2) +
              (pow((myPosition.y - y), 2)))) < 5){
        //cout<<"az avaaaaaaaal"<<endl;
        myPosition.x = fx;
        myPosition.y = fy ;


    }
    setTeta();
    item->setPos(myPosition.x , myPosition.y);

}
void Gun ::setTeta() {


    double aimx, aimy;
    if (myPosition.x == x) {
        //cout << "amodi" << endl;
        aimx = 0;
        if (myPosition.y < y)
            aimy = 1;
        else
            aimy = -1;
    }
    else if (myPosition.y == y) {
        aimy = 0;
        if (myPosition.x < x)
            aimx = 1;
        else
            aimx = -1;

    }
    else {
      //  cout << fabs(cos(atan((aimy - myPosition.y) / (aimx - myPosition.x)))) << endl;
        aimx = fabs(cos(atan((y - myPosition.y) / (x - myPosition.x))));
        aimy = fabs(sin(atan((y - myPosition.y) / (x - myPosition.x))));
        //     cout<<"GEEG "<<aimx<<endl;
        if (x < myPosition.x)
            aimx *= -1;
        if (y < myPosition.y)
            aimy *= -1;

    }
    //cout << aimx << endl;
    myPosition.x += (10 * aimx);
    myPosition.y += (10 * aimy);

    //   cout<<"set enemy"<<myPosition.x << " " << myPosition.y << endl;

}