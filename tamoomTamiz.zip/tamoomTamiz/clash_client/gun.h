//
// Created by ghazal on 7/4/16.
//

#ifndef CLASH_CLIENT_GUN_H
#define CLASH_CLIENT_GUN_H

#include <QtWidgets/QDialog>
#include <QtWidgets/QGraphicsItem>

class Gun : public QDialog{
    Q_OBJECT

public:
    struct position{
        double x ;
        double y ;
        double teta ;
    };
    position myPosition ;
    int x ,  y ,fx,fy;
    Gun(QGraphicsItem* item, QTimer* timer,int fx ,int fy , int x , int y, double v , QWidget *parent = 0 );
    int m ;
    double v ;
    QTimer *t;
    void setTeta();
    void setAim(int x , int y);

private slots:
    void f();
public:
    QGraphicsItem* item;
    QTimer* timer;
};

#endif //CLASH_CLIENT_GUN_H
