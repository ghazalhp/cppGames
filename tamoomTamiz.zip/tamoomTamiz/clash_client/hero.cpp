//
// Created by ghazal on 7/5/16.
//
#include <QtWidgets>
#include <QtNetwork>
#include <hero.h>
#include <iostream>
#include <math.h>
#include <stdio.h>
#include "gun.h"
#include "finish.h"
#include "lava-pop.h"
#include "minion-horde.h"
#include "skeleton.h"
#include "hog-rider.h"
#include "inferno-tower.h"
#include "using-furnace.h"
#include "royal-giant.h"
//TODO Drak Prince - inferno tower - miror - rage - furnance - witch - zap

using namespace std;
hero ::hero()  {
  /*  setCacheMode(NoCache);
    setAcceptHoverEvents(true);
    setFlag(QGraphicsItem::ItemIsSelectable,true);*/
    costEx = 2 ;
    mode = true;
    if(myKind == tower)
        whoAmI = new target(building);
    myTargets = new vector<target* >;
    whoAmI =new target( nadaram );
    deployTime = 0 ;
    deployT = 0 ;
    t = new QTimer();
    hitSpeed = 1 ;
}
void hero ::prepareToMove(QTimer *timer1 , hero ** h , QGraphicsScene *s) {
    cout<<"prepare to mpve"<<name .toStdString() << " " << hitPoints<<endl;
    allHero = h ;
    scene = s ;
  //  t = timer ;

    hitPointsButten = new QGraphicsTextItem();
    hitPointsButten->setDefaultTextColor(Qt :: black);


    scene->addItem(hitPointsButten);
    cout<<"me"<< name.toStdString() <<  " " << myPosition.y <<  endl;
    deployT = 0 ;
    dpt = new QTimer();
    dpt->start(20);
    if(dynamic_cast<Inferno *>(this) != 0)
        this->hitPoints = 800;
    connect(dpt, SIGNAL(timeout()), this, SLOT(dT()));

}
void hero ::dT() {
  //  cout<<"dt"<<endl;
    deployT++;
    pixmap = new QPixmap();
    image = new QImage("watch2.png");
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);
    if(deployT > deployTime*80){
     //   cout<<"finishhhhhhhhhh"<<endl;
        dpt->stop();
        pixmap = 0;
        image = 0 ;
        pixmap = new QPixmap();
        image = new QImage(nameOfPicture);
        pixmap->convertFromImage(image->scaled(40, 40));
        setPixmap(*pixmap);

        if(dynamic_cast<Furnace *>(this) != 0)
            this->t->start(5000);
        else
            t->start(20);
        connect(t, SIGNAL(timeout()), this, SLOT(move()));
    }
}
void hero ::killEnemy() {
    cout<<"enemy  "<< enemy->name.toStdString() << " " << enemy->myPosition.x << " "<<enemy->groupId << " me  " << name.toStdString()<<  " " << myPosition.x<< " " << groupId<<endl;
        if(enemy == this)
            cout<<"ajab"<<endl;
   enemy->hitPoints -= this->damage;
    if(enemy->hitPoints <=0 ){
        enemy->alive = false ;
        enemy->t->stop();
        enemy->checkAlive();
        if(enemy != 0 && scene->items().contains(enemy))
            scene->removeItem(enemy);
        if(enemy->hitPointsButten != 0 &&scene->items().contains(enemy->hitPointsButten))
            scene->removeItem(enemy->hitPointsButten);
        if(enemy->gn != 0 &&scene->items().contains(enemy->gn->item))
            scene->removeItem(enemy->gn->item);
        if(gn != 0 &&scene->items().contains(gn->item))
            scene->removeItem(gn->item);


        if(enemy -> gn != 0)
            enemy->gn = 0;
        gn = 0 ;
        enemy = NULL;
    }
}
void hero ::fire(int x, int y) {
  //  cout<<"fire " << x << " "<< y << endl;
    if(gn == 0) {
        QGraphicsPixmapItem *grass = new QGraphicsPixmapItem();
        QPixmap pixmap;
        QImage *image = new QImage("/home/ghazal/ClionProjects/clash_client/tir.jpg");

        pixmap.convertFromImage(image->scaled(10, 10));
        grass->setPixmap(pixmap);
        grass->setPos(myPosition.x + 30, myPosition.y + 30);
        scene->addItem(grass);
        gn = new Gun(grass, t, myPosition.x + 30, myPosition.y + 30, x, y,hitSpeed);
    }
    else{
        if(!scene->items().contains(gn->item))
            scene->addItem(gn->item);
        gn->setAim(x,y);
        if( sqrt((pow((gn->myPosition.x - x), 2) +
                  (pow((gn->myPosition.y - y), 2)))) < 5) {
            killEnemy();
        }


    }
}
void hero ::setEnemy() {
    double min = 10000 ;
    int minI = 0;
    for(int i = 8 ; i < size ; i++) {
        if(allHero[i]->alive && scene->items().contains(allHero[i])){
            for (int j = 0; j < myTargets->size(); j++) {
                if (*myTargets->at(j) == *allHero[i]->whoAmI) {
                    double x2 = (double) (myPosition.x - allHero[i]->myPosition.x);
                    double y2 = (double) (myPosition.y - allHero[i]->myPosition.y);
                    if (min > sqrt(x2 * x2 + y2 * y2)) {
                        min = sqrt(x2 * x2 + y2 * y2);
                        minI = i;
                    }
                }
            }

        }



    }
 //   cout<<"myx" << myPosition.x<< " my y " << myPosition.y << endl;
    if((myPosition.x > 200 && myPosition.x < 230 ) || (myPosition .x > 700 && myPosition.x < 730)){
  //      cout<<"ro pol"<<myPosition.y <<endl;
        if(myPosition.y >275  && myPosition.y < 355){
          //  cout<<"toye if"<<endl;
            if(allHero[minI]->myPosition.y < 275){
                setTeta(myPosition.x , 275, true);
            }
            else
                setTeta(myPosition.x , 355, true);
            return;
        }


    }
    if(*whoAmI != air && dynamic_cast<HogRider *>(this) == 0) {
        if ((allHero[minI]->myPosition.y < 275 && myPosition.y < 275) ||
            (allHero[minI]->myPosition.y > 355 && myPosition.y > 355)) {
            //   cout << "invar onvar nist" << endl;
            setTeta(allHero[minI]->myPosition.x - 10, allHero[minI]->myPosition.y - 10, false);
            return;
        }
        else if (myPosition.x < 500) {
            // cout<<"bia inja dge"<<endl;
            if (myPosition.y <= 278) {
                //   cout<<"ghaedatan inja"<<endl;
                setTeta(210, 275, false);
            }
            else if (myPosition.y > 350)
                setTeta(210, 355, false);

        }
        else {
            if (myPosition.y <= 278)
                setTeta(710, 275, false);
            else if (myPosition.y > 350) {
                setTeta(710, 355, false);
                // cout<<"inja maaaan"<<endl;
            }
        }
    }
    else{
        setTeta(allHero[minI]->myPosition.x - 10, allHero[minI]->myPosition.y - 10, false);
    }




}
void hero ::setTeta(int x, int y , bool ropol) {
    if(dynamic_cast<HogRider *>(this) != 0 ) {
        if (y > 355 && myPosition.y>270 && myPosition.y < 355) {
            myPosition.y = 355+10;
            return;
        }
        if(y <275 && myPosition.y<355 && myPosition.y > 270  ) {
            myPosition.y = 275 - 10;
            return;
        }

    }
    if(ropol){

            if (y == 355) {
                myPosition.y += (mySpeed + 1);
                // cout<<"haminja"<<endl;
            }
            else
                myPosition.y -= (mySpeed + 1);

    }
    else {
        double aimx, aimy;
        if (myPosition.x == x) {
          //  cout << "amodi" << endl;
            aimx = 0;
            if (myPosition.y < y)
                aimy = 1;
            else
                aimy = -1;
        }
        else if (myPosition.y == y) {
            aimy = 0;
            if (myPosition.x < x)
                aimx = 1;
            else
                aimx = -1;

        }
        else {
         //   cout << fabs(cos(atan((aimy - myPosition.y) / (aimx - myPosition.x)))) << endl;
            aimx = fabs(cos(atan((aimy - myPosition.y) / (aimx - myPosition.x))));
            aimy = fabs(sin(atan((aimy - myPosition.y) / (aimx - myPosition.x))));
            //     cout<<"GEEG "<<aimx<<endl;
            if (x < myPosition.x)
                aimx *= -1;
            if (y < myPosition.y)
                aimy *= -1;

        }
       // cout << aimx << endl;
        myPosition.x += ((mySpeed + 1) * aimx);
        myPosition.y += ((mySpeed + 1) * aimy);
    }
 //   cout<<"set enemy"<<myPosition.x << " " << myPosition.y << endl;

}
void hero ::checkAlive() {
    if(!alive){
        t->stop();

    }

}
void hero ::checklp() {
    for(int i = 0 ; i < scene->items().size();i++){
        if(dynamic_cast<LavaPop*>(scene->items().at(i))!= 0) {
            LavaPop *l = (LavaPop *) scene->items().at(i);
            if (l->groupId != this->groupId) {
                emergancy = true;
                if (l->alive && scene->items().contains(l) ) {

                    for (int j2 = 0; j2 < myTargets->size(); j2++) {
                  //      cout << "biaaa" << *myTargets->at(j2) << endl;
                        if (*myTargets->at(j2) == *l->whoAmI ) {
                    //        cout << "to if " << i << endl;
                            if ((range > 1 && sqrt((pow((myPosition.x - l->myPosition.x), 2) +
                                                    (pow((myPosition.y - l->myPosition.y), 2)))) < range * 30) ||
                                (sqrt((pow((myPosition.x - l->myPosition.x), 2) +
                                       (pow((myPosition.y - l->myPosition.y), 2)))) < 50)) {
                                //     cout << "to ifffffffff" << allHero[i]->name.toStdString() << endl;
                                enemy = l;
                                fire(l->myPosition.x, l->myPosition.y);
                                needShoot = true;
                                break;
                            }
                            else if (enemy == l) {
                                if (gn != NULL && scene->items().contains(gn->item))
                                    scene->removeItem(gn->item);
                                enemy = NULL;
                                needShoot = false;
                                emergancy = false;
                            }
                        }
                    }
                //    cout << "f for" << endl;
                }
            }
        }
    }
}
void hero ::checkMH() {
    for(int i = 0 ; i < scene->items().size();i++){
        if(dynamic_cast< MinionHorde*>(scene->items().at(i))!= 0) {
            MinionHorde *l = ( MinionHorde *) scene->items().at(i);
            if (l->groupId != this->groupId) {

                if (l->alive && scene->items().contains(l)) {

                    for (int j2 = 0; j2 < myTargets->size(); j2++) {
            //            cout << "biaaa" << *myTargets->at(j2) << endl;
                        if (*myTargets->at(j2) == *l->whoAmI) {
              //              cout << "to if " << i << endl;
                            if ((range > 1 && sqrt((pow((myPosition.x - l->myPosition.x), 2) +
                                                    (pow((myPosition.y - l->myPosition.y), 2)))) < range * 30) ||
                                (sqrt((pow((myPosition.x - l->myPosition.x), 2) +
                                       (pow((myPosition.y - l->myPosition.y), 2)))) < 50)) {
                                //     cout << "to ifffffffff" << allHero[i]->name.toStdString() << endl;
                                emergancy =  true;
                                enemy = l;
                                fire(l->myPosition.x, l->myPosition.y);
                                needShoot = true;
                                break;
                            }
                            else if (enemy == l) {
                                if (gn != NULL && scene->items().contains(gn->item))
                                    scene->removeItem(gn->item);
                                enemy = NULL;
                                needShoot = false;
                                emergancy = false;
                            }
                        }
                    }
          //          cout << "f for" << endl;
                }
            }
        }
    }
}

void hero ::checkS() {
    for(int i = 0 ; i < scene->items().size();i++){
        if(dynamic_cast< Skeleton *>(scene->items().at(i))!= 0) {
            Skeleton *l = (Skeleton *) scene->items().at(i);
            if (l->groupId != this->groupId) {

                if (l->alive && scene->items().contains(l)) {

                    for (int j2 = 0; j2 < myTargets->size(); j2++) {
                        //            cout << "biaaa" << *myTargets->at(j2) << endl;
                        if (*myTargets->at(j2) == *l->whoAmI) {
                            //              cout << "to if " << i << endl;
                            if ((range > 1 && sqrt((pow((myPosition.x - l->myPosition.x), 2) +
                                                    (pow((myPosition.y - l->myPosition.y), 2)))) < range * 30) ||
                                (sqrt((pow((myPosition.x - l->myPosition.x), 2) +
                                       (pow((myPosition.y - l->myPosition.y), 2)))) < 50)) {
                                //     cout << "to ifffffffff" << allHero[i]->name.toStdString() << endl;
                                emergancy =  true;
                                enemy = l;
                                fire(l->myPosition.x, l->myPosition.y);
                                needShoot = true;
                                break;
                            }
                            else if (enemy == l) {
                                if (gn != NULL && scene->items().contains(gn->item))
                                    scene->removeItem(gn->item);
                                enemy = NULL;
                                needShoot = false;
                                emergancy = false;
                            }
                        }
                    }
                    //          cout << "f for" << endl;
                }
            }
        }
        else if(dynamic_cast< FireSpirit *>(scene->items().at(i))!= 0){
            FireSpirit *l = (FireSpirit *) scene->items().at(i);
            if (l->groupId != this->groupId) {

                if (l->alive && scene->items().contains(l)) {

                    for (int j2 = 0; j2 < myTargets->size(); j2++) {
                        //            cout << "biaaa" << *myTargets->at(j2) << endl;
                        if (*myTargets->at(j2) == *l->whoAmI) {
                            //              cout << "to if " << i << endl;
                            if ((range > 1 && sqrt((pow((myPosition.x - l->myPosition.x), 2) +
                                                    (pow((myPosition.y - l->myPosition.y), 2)))) < range * 30) ||
                                (sqrt((pow((myPosition.x - l->myPosition.x), 2) +
                                       (pow((myPosition.y - l->myPosition.y), 2)))) < 50)) {
                                //     cout << "to ifffffffff" << allHero[i]->name.toStdString() << endl;
                                emergancy =  true;
                                enemy = l;
                                fire(l->myPosition.x, l->myPosition.y);
                                needShoot = true;
                                break;
                            }
                            else if (enemy == l) {
                                if (gn != NULL && scene->items().contains(gn->item))
                                    scene->removeItem(gn->item);
                                enemy = NULL;
                                needShoot = false;
                                emergancy = false;
                            }
                        }
                    }
                    //          cout << "f for" << endl;
                }
            }
        }
    }
}
void hero ::move() {


       //cout<<"move"<< name.toStdString() << " " << hitPoints << endl;

    if(!mode)
        size = 13 ;

    if(alive) {
        //cout<<"emm"<<endl;
        needShoot = false ;
        checkAlive();
        //cout<<"emm"<<endl;
         emergancy = false;
        checklp();
        //cout<<"lp oke"<<endl;
        if(!emergancy)
            checkMH();
        if(!emergancy)
            checkS();
       // cout<<"naresidam"<<endl;
        QString x;
        x.setNum(hitPoints);
        hitPointsButten->setPlainText(x);
        hitPointsButten->setPos(this->pos().x()-18,this->pos().y()-18);
        if (enemy == NULL || (enemy != 0 && !scene->items().contains(enemy)) ) {
            needShoot = 0;
            if( gn != NULL &&  scene->items().contains(gn->item)) {
                scene->removeItem(gn->item);
                if(gn != 0 )
                    gn = 0;
            }
            //   cout<<"LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL"<<endl;
        }

    //cout<<"rad nemikonam "<<endl;
        for (int i = 0;  i < size; i++) {
            if(enemy != NULL && enemy == allHero[i] && !(enemy->alive ) ) {
                if (gn != NULL && scene->items().contains(gn->item)) {
                    scene->removeItem(gn->item);
                    if(gn != 0 )
                        gn = 0 ;

                }
                needShoot = false;
            }
            if (allHero[i]->alive && scene->items().contains(allHero[i]) && allHero[i]->myType != spell) {
                for (int j2 = 0; j2 < myTargets->size(); j2++) {

      //              cout<<"biaaa"<<*myTargets->at(j2)<<endl;
                    if ( *myTargets->at(j2) == *allHero[i]->whoAmI || allHero[i]->myKind == tower) {
                        if(dynamic_cast<RoyalGiant *>(this))
                            cout<<"omaaadaaaaaaaaaam" << endl;
        //                cout<<"to if "<< i << endl;
                        if ((range >= 1 && sqrt((pow((myPosition.x - allHero[i]->myPosition.x), 2) +
                                                (pow((myPosition.y - allHero[i]->myPosition.y), 2)))) < range * 30) ||
                            (sqrt((pow((myPosition.x - allHero[i]->myPosition.x), 2) +
                                   (pow((myPosition.y - allHero[i]->myPosition.y), 2)))) < 50)) {
                            if(dynamic_cast<RoyalGiant *>(this))
                                cout << "to ifffffffff" <<name.toStdString() << " " <<  allHero[i]->name.toStdString() << endl;
                            enemy = allHero[i];
                            fire(allHero[i]->myPosition.x, allHero[i]->myPosition.y);
                            needShoot = true;
                              break;
                        }
                        else if(enemy == allHero[i]) {
                            if (gn != NULL && scene->items().contains(gn->item))
                                scene->removeItem(gn->item);
                            enemy = NULL;
                            needShoot = false;
                        }
                    }
                }
          //      cout<<"f for"<<endl;
            }
        }

        if (!needShoot && myKind == human && !emergancy) {

            if (gn != NULL && scene->items().contains(gn->item))
                scene->removeItem(gn->item);
            setEnemy();
            setPos(myPosition.x, myPosition.y);
        }
    }

}

void hero::mousePressEvent(QGraphicsSceneMouseEvent *event) {
   // cout << "mouuuuse" << endl;
}
void hero::mouseMoveEvent(QGraphicsSceneMouseEvent *event) {
   // cout<<"emmmm"<<endl;
    setPos(event->pos());

}