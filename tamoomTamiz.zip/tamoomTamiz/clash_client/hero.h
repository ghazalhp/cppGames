//
// Created by ghazal on 6/26/16.
//

#ifndef CLASH_CLIENT_HERO_H
#define CLASH_CLIENT_HERO_H

#include <QtCore/QString>
#include <QtGui/QIcon>
#include <QtWidgets/QGraphicsPixmapItem>
#include <QTimer>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGraphicsPixmapItem>
#include <hero.h>
#include <vector>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGraphicsPixmapItem>
#include <hero.h>
#include <vector>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include "gun.h"

using namespace std;
class hero : public QObject, public QGraphicsPixmapItem{
    Q_OBJECT
public:
    struct position{
        double x ;
        double y ;
        double teta ;
    };

    position myPosition ;
    bool alive = false;
    int id ;
    int groupId ;
    QString name ;
    double hitSpeed;
    enum speed {slow , medium , fast , veryFast};
    speed mySpeed;
    double deployTime;
    int deployT;
    double range = 0;
    int costEx ;
    enum heroKind {tower , human};
    heroKind myKind = human ;
    enum target {building , air ,ground , nadaram};
    vector< target* > *myTargets ;
    target* whoAmI ;
    enum type {spell , troop};
    type  myType ;
    int summons;
    int hitPoints ;
    int life;
    int lifeTime = 0 ;
    int damage ;
    QGraphicsTextItem *hitPointsButten ;
    QIcon *picture ;
    QGraphicsPixmapItem *myItem ;
    QPixmap *pixmap ;
    QImage *image ;
    QString nameOfPicture ;
    hero();
    hero ** allHero;
    QGraphicsScene *scene ;
    QTimer *t;
    QTimer * dpt ;
    bool needShoot = false ;
    void fire(int x , int y);
    virtual void prepareToMove(QTimer *timer  ,hero ** h ,QGraphicsScene *s);
    bool mode ;
    int size =11;
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseMoveEvent(QGraphicsSceneMouseEvent * event);
    void setTeta(int x , int y , bool ropol);
  //  int aimx , aimy ;
    void setEnemy();
    Gun *gn = 0;
    virtual  void killEnemy();
    void checklp();
    void checkMH();
    void checkS();
    bool  emergancy= false ;
    hero * enemy ;
    virtual  void checkAlive();

public slots:

    virtual void move();
    void dT();

};
#endif //CLASH_CLIENT_HERO_H
