//
// Created by ghazal on 6/27/16.
//

#include "hog-rider.h"

HogRider ::HogRider() {
    name = "hog-rider";
    id = 9;
    hitSpeed = 1.5;
    deployTime = 1;
    range = 0;
    costEx = 4 ;
    hitPoints = 800 ;
    damage = 150 ;
    life = hitPoints;
    mySpeed = veryFast;
    whoAmI = new target(ground);
    myTargets = new vector<target* >;
    myTargets->push_back(new target (building));
    myType = troop;
    nameOfPicture = "10.png";
    picture = new QIcon("10.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);
}