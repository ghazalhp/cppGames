//
// Created by ghazal on 6/27/16.
//

#ifndef CLASH_CLIENT_HOG_RIDER_H
#define CLASH_CLIENT_HOG_RIDER_H

#include "hero.h"

class HogRider: public hero{
public:
    HogRider();

};

#endif //CLASH_CLIENT_HOG_RIDER_H
