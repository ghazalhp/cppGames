//
// Created by ghazal on 6/27/16.
//


#include "ice-wizard.h"

IceWizard ::IceWizard()  {
    name = "ice-wizard";
    id = 3;
    hitSpeed = 1.2;
    deployTime = 1;
    range = 5;
    costEx = 3 ;
    hitPoints = 700 ;
    damage = 63 ;
    life = hitPoints;
    mySpeed = medium;
    whoAmI = new target(ground);
    myTargets = new vector<target* >;
    myTargets->push_back(new target (air));
    myTargets->push_back(new target (ground));
    myTargets->push_back(new target (building));
    myType = troop;
    nameOfPicture = "4.png";
    picture = new QIcon("4.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);
}
