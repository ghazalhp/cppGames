//
// Created by ghazal on 6/27/16.
//

#ifndef CLASH_CLIENT_ICE_WIZARD_H
#define CLASH_CLIENT_ICE_WIZARD_H

#include "hero.h"

class IceWizard : public hero{
public:
    IceWizard();

};

#endif //CLASH_CLIENT_ICE_WIZARD_H
