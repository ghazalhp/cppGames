#include <iostream>
#include "inferno-tower.h"

//
// Created by ghazal on 6/29/16.
//
Inferno::Inferno()  {
    name = "inferno-tower";
    id = 14;
    myKind = tower ;
    whoAmI = new target(building);
    hitPoints = 800;
    hitSpeed =  0.4;
    range = 6.5 ;
    damage = 400;
    myType = troop;
    whoAmI = new target(building);
    myTargets = new vector<target* >;
    myTargets->push_back(new target (building));
    myTargets->push_back(new target (air));
    myTargets->push_back(new target (ground));
    mySpeed = slow;
    deployTime = 1;
    costEx = 5;
    orginalDamage = damage;

    nameOfPicture = "15.png";
    picture = new QIcon("15.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);



}
 void Inferno :: checkAlive(){
     if(!alive){
         t->stop();

     }
     else{
         cout<<"inf cA"<<endl;
         if(enemy != 0){
             if(lastEnemy != 0){
                 if(lastEnemy != enemy){
                     damage = orginalDamage;
                     lastEnemy = enemy;
                 }
             }
         }
         cout<<"hp"<<hitPoints<<endl;
         hitPoints--;
         cout<<"hp"<<hitPoints<<endl;
         lifeTime++;
         if(lifeTime >=200){
             damage*=2;
             lifeTime = 0 ;
         }
         if(hitPoints<=0){
             alive = false;
             if(gn!= 0 && scene->items().contains(gn->item))
                 scene->removeItem(gn->item);
             if(hitPointsButten != 0 &&scene->items().contains(hitPointsButten))
                 scene->removeItem(hitPointsButten);
             scene->removeItem(this);
         }
     }
}