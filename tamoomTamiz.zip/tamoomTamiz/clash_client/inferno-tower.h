//
// Created by ghazal on 6/29/16.
//

#ifndef CLASH_CLIENT_INFERNO_TOWER_H
#define CLASH_CLIENT_INFERNO_TOWER_H

#include "hero.h"

class Inferno : public hero{
public:
    Inferno();
    virtual  void checkAlive();
    hero *lastEnemy = 0 ;
    int  orginalDamage ;

};
#endif //CLASH_CLIENT_INFERNO_TOWER_H
