//
// Created by ghazal on 7/3/16.
//

#include "king.h"

King ::King() {
    myKind = tower ;
    range = 8 ;
    id = 8 ;
    name = "king";
    hitPoints = 2000 ;
    damage = 100 ;
    life = hitPoints;
    nameOfPicture = "king.jpg";
    picture = new QIcon("king.jpg");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);
    hitSpeed = 5;
    deployTime = 0;
    whoAmI = new target(building);
    myTargets = new vector<target* >;
    myTargets->push_back(new target (building));
    myTargets->push_back(new target (ground));
    myTargets->push_back(new target (air));

}