//
// Created by ghazal on 7/3/16.
//

#ifndef CLASH_CLIENT_KING_H
#define CLASH_CLIENT_KING_H

#include "hero.h"

class King : public hero{
public:
    King();
};
#endif //CLASH_CLIENT_KING_H
