//
// Created by ghazal on 6/27/16.
//

#include <iostream>
#include "lava-hound.h"

LavaHound ::LavaHound() {
    cout<<"lavaHo"<<endl;
    myItem = new QGraphicsPixmapItem();

    name = "lava-hound";
    id = 0;
    hitSpeed = 1.3;
    deployTime = 1;
    range = 2;
    costEx = 7 ;
    hitPoints = 3000 ;
    damage = 45 ;
    whoAmI = new target(ground);
    life = hitPoints;
    mySpeed = slow;
    myTargets = new vector<target* >;
    myTargets->push_back(new target (building));
    myType = troop;
    nameOfPicture = "1.png";
    picture = new QIcon("1.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);
    lp = new LavaPop*[6];
}
void LavaHound ::checkAlive() {
    if(!alive){
        for(int i =0 ; i < 6 ; i ++){
            lp[i]= new LavaPop();
            lp[i]->setPos(this->pos());
            if(i%2 == 0) {
                lp[i]->myPosition.x = this->myPosition.x + (i * 10);
                lp[i]->myPosition.y = this->myPosition.y ;
            }
            else {
                lp[i]->myPosition.x = this->myPosition.x ;
                lp[i]->myPosition.y = this->myPosition.y + (i * 10);
            }
        scene->addItem(lp[i]);
        lp[i]->hitPoints = lp[i]->life;
        lp[i]->alive = true;
        lp[i]->groupId = this->groupId ;

        lp[i]->prepareToMove(t, allHero, scene);
        }
    }
}