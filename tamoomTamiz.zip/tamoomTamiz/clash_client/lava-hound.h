//
// Created by ghazal on 6/27/16.
//

#ifndef CLASH_CLIENT_LAVA_HOUND_H
#define CLASH_CLIENT_LAVA_HOUND_H

#include "hero.h"
#include "lava-pop.h"

class LavaHound : public hero{
public:
    LavaHound();
    void setPositoin(int x , int y , double teta);
    virtual void checkAlive();
    LavaPop ** lp;
};
#endif //CLASH_CLIENT_LAVA_HOUND_H
