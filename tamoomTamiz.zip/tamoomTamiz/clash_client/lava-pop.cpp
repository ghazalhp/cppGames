//
// Created by ghazal on 6/27/16.
//

#include <iostream>
#include "lava-hound.h"
#include "lava-pop.h"

LavaPop ::LavaPop()  {
    cout<<"lavapop"<<endl;
    myItem = new QGraphicsPixmapItem();

    name = "lava-pop";
    id = 16;
    hitSpeed = 1;
    deployTime = 0;
    range = 3;
    costEx = 1 ;
    hitPoints = 180;
    damage = 45 ;
    whoAmI = new target(air);
    life = hitPoints;
    mySpeed = fast;
    myTargets = new vector<target* >;
    myTargets->push_back(new target (building));
    myTargets->push_back(new target (air));
    myTargets->push_back(new target (ground));
    myType = troop;
    nameOfPicture = "16.png";
    picture = new QIcon("16.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(20, 20));
    setPixmap(*pixmap);

}
