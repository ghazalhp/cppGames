//
// Created by ghazal on 7/19/16.
//

#ifndef CLASH_CLIENT_LAVA_POP_H
#define CLASH_CLIENT_LAVA_POP_H

#include "hero.h"

class LavaPop : public hero{
public:
    LavaPop();


};
#endif //CLASH_CLIENT_LAVA_POP_H
