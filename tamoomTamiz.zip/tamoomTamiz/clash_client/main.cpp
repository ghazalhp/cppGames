#include <iostream>
#include "startMenu.h"
#include "game.h"
#include "manager.h"
#include <QApplication>
using namespace std;

int main(int argc, char **argv) {
    QApplication app(argc, argv);
    cout << "Hello, World th n!" << endl;
    manager *m = new manager() ;
    m->show();





    return app.exec();
}