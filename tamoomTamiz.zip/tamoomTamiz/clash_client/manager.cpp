//
// Created by ghazal on 6/26/16.
//

#include <QtWidgets/QMainWindow>
#include <iostream>
#include <QtMultimedia/QMediaPlaylist>
#include "manager.h"
#include "startMenu.h"
#include "game.h"
#include "cards.h"
#include "erors.h"
using  namespace std;
manager::manager(QWidget * start):QMainWindow(start) {
    cout<<"m"<<endl;
    setFixedSize(1000, 700);
    setGeometry(300,0,1000,700);

    allPage = new QStackedWidget(this);
    setWindowTitle("clash Royale");
    menu *m= new menu(this) ;
    cout<<"ino migiram"<<m->mode<<endl;
    allPage-> addWidget(m);
    allPage -> setCurrentWidget(m);
    setCentralWidget(allPage);
    connect(m->start, SIGNAL(clicked()), this, SLOT(switchP()));
    connect(m->exit, SIGNAL(clicked()), this, SLOT(closeAll()));
    connect(m->card, SIGNAL(clicked()), this, SLOT(setcards()));
    connect(m->notification, SIGNAL(clicked()), this, SLOT(setModeTrue()));
    connect(m->notification2, SIGNAL(clicked()), this, SLOT(setModeFalse()));
    playM();


}
void manager ::closeAll() {
    close();
}
void manager ::playM() {
    pl = new QMediaPlaylist();
    pl->addMedia(QUrl::fromLocalFile(QFileInfo("92-93_miraas.mp3").absoluteFilePath()));
    pl->setPlaybackMode(QMediaPlaylist::Loop);
    play = new QMediaPlayer();
    play->setPlaylist(pl);
   // play->setMedia(QUrl::fromLocalFile(QFileInfo("92-93_miraas.mp3").absoluteFilePath()));
    play->setVolume(100);
    play->play();
}
void manager ::setcards() {
    c= new cards() ;
    allPage-> addWidget(c);
    allPage -> setCurrentWidget(c);
    connect(c->start, SIGNAL(clicked()), this, SLOT(backToManu()));
}
void manager ::backToManu() {
    if(c->listOfCards->size() == 8)
        allPage -> setCurrentIndex(0);
    else
        c->moreOrLess(-1);
}
void manager ::qFromgame() {
    allPage -> setCurrentIndex(0);
}
void manager ::setModeTrue() {
    cout<<"make mode true" << endl ;
    mode = true;
}
void  manager ::setModeFalse() {
    cout<< " make mode false "<< endl;
    mode = false ;
}
void manager ::mute() {
    m++;
    if(m%2 == 1)
        play-> pause();
    else
        play->play();
}
void manager ::switchP() {
    cout << "sitchP" << endl;
    cout<<"ino midam behesh" << mode << endl;
    g= new game(c->listOfCards,name,"127.0.0.1", "127.0.0.1",mode);
    cout<<"after make game board";
    allPage->addWidget(g);
    allPage->setCurrentWidget(g);
    connect(g->q, SIGNAL(clicked()), this, SLOT(qFromgame()));
    connect(g->m, SIGNAL(clicked()), this, SLOT(mute()));



}
