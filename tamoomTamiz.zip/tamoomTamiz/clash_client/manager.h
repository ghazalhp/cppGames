//
// Created by ghazal on 6/26/16.
//

#include <QtWidgets/QMainWindow>
#include <QtWidgets/QStackedWidget>
#include <QtMultimedia/QMediaPlayer>
#include "cards.h"
#include "game.h"


#ifndef CLASH_CLIENT_MANAGER_H
#define CLASH_CLIENT_MANAGER_H
class manager :public  QMainWindow{
    Q_OBJECT
public :
    manager(QWidget * = 0);
    QStackedWidget *allPage ;
    cards * c;
    game *g ;
    QString name ;
    bool mode ;
    QMediaPlaylist *pl ;
    QMediaPlayer *play ;
    int m = 0 ;
public slots:
    void switchP();
    void setcards();
    void backToManu();
    void qFromgame();
    void closeAll();
    void setModeTrue();
    void setModeFalse();
    void playM();
    void mute();
};

#endif //CLASH_CLIENT_MANAGER_H
