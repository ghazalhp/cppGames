//
// Created by ghazal on 6/27/16.
//

#include "miner.h"

Miner ::Miner()  {
    name = "miner";
    id = 5;
    hitSpeed = 1.2;
    deployTime = 1;
    range = 0;
    costEx = 3;
    hitPoints = 1000 ;
    damage = 160 ;
    life = hitPoints;
    mySpeed = slow;
    whoAmI = new target(ground);
    myTargets = new vector<target* >;
    myTargets->push_back(new target (ground));
    myTargets->push_back(new target (building));
    myType = troop;
    nameOfPicture = "6.png";
    picture = new QIcon("6.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);

}