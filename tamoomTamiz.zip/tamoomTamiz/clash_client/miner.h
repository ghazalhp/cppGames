//
// Created by ghazal on 6/27/16.
//

#ifndef CLASH_CLIENT_MINER_H
#define CLASH_CLIENT_MINER_H

#include "hero.h"

class Miner : public hero{
public:
    Miner();

};
#endif //CLASH_CLIENT_MINER_H
