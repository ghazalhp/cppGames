//
// Created by ghazal on 6/27/16.
//


#include <iostream>
#include "minion-horde.h"

MinionHorde ::MinionHorde()  {
    name = "minion-horde";
    id = 2;
    hitSpeed = 1;
    deployTime = 1;
    range = 2.5;
    costEx = 5 ;
    hitPoints = 90 ;
    damage = 40 ;
    whoAmI = new target(air);
    life = hitPoints;
    mySpeed = fast;
    myTargets = new vector<target* >;
    myTargets->push_back(new target (air));
    myTargets->push_back(new target(ground));
    myTargets->push_back(new target (building));
    myType = troop;
    nameOfPicture = "3.png";
    picture = new QIcon("3.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);

}
void MinionHorde ::prepareToMove(QTimer *timer1 , hero ** h , QGraphicsScene *s) {
    cout<<"prepare to mpve"<<name .toStdString() << endl;
    allHero = h ;
    scene = s ;
    //  t = timer ;
    t = new QTimer();
    t->start(20);
    hitPointsButten = new QGraphicsTextItem();
    hitPointsButten->setDefaultTextColor(Qt :: black);

    if(!child){
        mh = new MinionHorde*[5];
        for(int i =0 ; i < 5 ; i ++){
            mh[i]= new MinionHorde();

            if(i <  2) {
                mh[i]->myPosition.x = this->myPosition.x;
                mh[i]->myPosition.y = this->myPosition.y+(i*20) ;
            }
            else {
                mh[i]->myPosition.x = this->myPosition.x+50 ;
                mh[i]->myPosition.y = this->myPosition.y + ((i-2) * 20);
            }
            mh[i]->child = true;
            mh[i]->setPos(mh[i]->myPosition.x , mh[i]->myPosition.y);
            scene->addItem(mh[i]);
            mh[i]->hitPoints = mh[i]->life;
            mh[i]->alive = true;
            mh[i]->groupId = this->groupId ;

            mh[i]->prepareToMove(t, allHero, scene);
        }
    }

    scene->addItem(hitPointsButten);
    cout<<"me"<< name.toStdString() <<  " " << myPosition.y <<  endl;
    deployT = 0 ;
    dpt = new QTimer();
    dpt->start(20);
    connect(dpt, SIGNAL(timeout()), this, SLOT(dT()));
}