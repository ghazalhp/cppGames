//
// Created by ghazal on 6/27/16.
//

#ifndef CLASH_CLIENT_MINION_HORDE_H
#define CLASH_CLIENT_MINION_HORDE_H

#include "hero.h"

class MinionHorde : public hero{
public:
    MinionHorde();
    bool child = false ;
    virtual void prepareToMove(QTimer *timer  ,hero ** h ,QGraphicsScene *s);
    MinionHorde ** mh ;

};

#endif //CLASH_CLIENT_MINION_HORDE_H
