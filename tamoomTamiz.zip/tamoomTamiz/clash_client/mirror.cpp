#include "mirror.h"

//
// Created by ghazal on 6/27/16.
//
Mirror ::Mirror() {
    name = "mirror";
    id = 10;
    nameOfPicture = "11.png";
    picture = new QIcon("11.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);


}