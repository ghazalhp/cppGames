//
// Created by ghazal on 6/27/16.
//

#ifndef CLASH_CLIENT_MIRROR_H
#define CLASH_CLIENT_MIRROR_H

#include "hero.h"

class Mirror : public hero{
public:
    Mirror();
};

#endif //CLASH_CLIENT_MIRROR_H
