//
// Created by ghazal on 7/3/16.
//

#include "queen.h"

Queen ::Queen()  {
    myKind = tower ;
    range = 6;
    id = 9 ;
    hitPoints = 1500 ;
    damage = 50 ;
    life = hitPoints;
    name = "queen";
    nameOfPicture = "queen.jpg";
    picture = new QIcon("queen.jpg");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);
    hitSpeed = 5;
    deployTime = 0;
    whoAmI = new target(building);
    myTargets = new vector<target* >;
    myTargets->push_back(new target (building));
    myTargets->push_back(new target (ground));
    myTargets->push_back(new target (air));



}