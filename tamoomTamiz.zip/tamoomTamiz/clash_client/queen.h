//
// Created by ghazal on 7/3/16.
//

#ifndef CLASH_CLIENT_QUEEN_H
#define CLASH_CLIENT_QUEEN_H

#include "hero.h"

class Queen : public hero{
public:
    Queen();
};
#endif //CLASH_CLIENT_QUEEN_H
