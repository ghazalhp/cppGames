#include <iostream>
#include "rage.h"
#include "using-furnace.h"

//
// Created by ghazal on 6/27/16.
//
Rage ::Rage()  {
    name = "rage";
    id = 12;

    range = 5;
    costEx = 3 ;
    myTargets = new vector<target* >;
    myTargets->push_back(new target (building));
    myTargets->push_back(new target (air));
    myTargets->push_back(new target (ground));
    myType = spell;
    nameOfPicture = "13.png";
    picture = new QIcon("13.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);
    lifeTime = 0 ;
    victim = new QList<hero *>;

}


void  Rage ::move() {
    lifeTime++;
    if(!mode)
        size = 13 ;

    if(alive) {
        cout<<"raaage move"<<  endl;
        checkAlive();


        for(int i = 0 ; i < scene->items().size();i++){
            if(dynamic_cast< hero*>(scene->items().at(i))!= 0) {
                hero *l = ( hero *) scene->items().at(i);

                    if (l->alive && scene->items().contains(l) && l->groupId == groupId) {

                        if ((range > 1 && sqrt((pow((myPosition.x - l->myPosition.x), 2) +
                                                (pow((myPosition.y - l->myPosition.y), 2)))) < range * 30) ||
                            (sqrt((pow((myPosition.x - l->myPosition.x), 2) +
                                   (pow((myPosition.y - l->myPosition.y), 2)))) < 50)) {

                            enemy = l;
                            victim->push_back(l);
                            if(dynamic_cast<Furnace * >(l) != 0)
                                enemy->t->start(2500);
                            else
                                enemy->t->start(10);
                        }



                        //          cout << "f for" << endl;

                }
            }
        }

        if(lifeTime >= 100){
            for(int i = 0 ; i < victim->size() ;i++){
                if(victim->at(i)!= 0 && victim->at(i)->alive)
                    victim->at(i)->t->start(20);
            }
            cout<<" rage mord"<<endl;
            lifeTime = 0 ;
            alive = false;
            scene->removeItem(this);
        }
    }
    //cout<<"tahe rage move"<<endl;
}