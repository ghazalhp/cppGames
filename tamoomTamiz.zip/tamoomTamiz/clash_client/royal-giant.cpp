//
// Created by ghazal on 6/27/16.
//

#include "royal-giant.h"

RoyalGiant::RoyalGiant() {
    name = "royal-giant";
    id = 8;
    hitSpeed = 1.5;
    deployTime = 1;
    costEx = 6 ;
    hitPoints = 1200 ;
    damage = 231;
    range = 6 ;
    life = hitPoints;
    mySpeed = slow;
    myTargets = new vector<target* >;
    myTargets->push_back(new target (building));
    whoAmI = new target(ground);
    myType = troop;
    nameOfPicture = "9.png";
    picture = new QIcon("9.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);
}
