//
// Created by ghazal on 6/27/16.
//

#include "hero.h"

#ifndef CLASH_CLIENT_ROYAL_GIANT_H
#define CLASH_CLIENT_ROYAL_GIANT_H

class RoyalGiant :public hero{
public:
    RoyalGiant();

};

#endif //CLASH_CLIENT_ROYAL_GIANT_H