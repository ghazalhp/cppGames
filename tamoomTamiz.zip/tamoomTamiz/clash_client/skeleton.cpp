

//
// Created by ghazal on 6/27/16.
//

#include <iostream>
#include "skeleton.h"


Skeleton ::Skeleton() {
    cout<<"skeleton"<<endl;
    myItem = new QGraphicsPixmapItem();

    name = "skeleton";
    id = 18;
    hitSpeed = 1;
    deployTime = 1;
    range = 2;
    costEx = 1 ;
    hitPoints = 43;
    damage = 80 ;
    whoAmI = new target(ground);
    life = hitPoints;
    mySpeed = veryFast;
    myTargets = new vector<target* >;
    myTargets->push_back(new target (building));
    myTargets->push_back(new target (air));
    myTargets->push_back(new target (ground));
    myType = troop;
    nameOfPicture = "s.png";
    picture = new QIcon("s.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(20, 20));
    setPixmap(*pixmap);



}
