//
// Created by ghazal on 7/21/16.
//

#ifndef CLASH_CLIENT_SKELETON_H
#define CLASH_CLIENT_SKELETON_H
#include "hero.h"

class Skeleton : public hero {
public:
    Skeleton();
};
#endif //CLASH_CLIENT_SKELETON_H
