//
// Created by ghazal on 6/26/16.
//

#include <QtWidgets/QCheckBox>
#include <iostream>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QPushButton>
#include "startMenu.h"
#include "game.h"
#include "manager.h"

using  namespace std;
menu ::menu(manager *x) {
    m = x;
    board();
}
void menu ::board() {
    setFixedSize(1000,700);
    setGeometry(600,0,1000,700);
    QPalette color(palette());
    color.setColor(QPalette::Background,Qt::black);
    setAutoFillBackground(true);
    setPalette(color);
    QLabel *picture = new QLabel(this);
    picture->setStyleSheet(" QLabel{ background-color : yellow; color : yellow; }");
    picture->setPixmap(QPixmap("menu.jpg"));
    picture->setGeometry(0,0,1000,700);
    picture->setAlignment(Qt::AlignCenter);
    picture->setAttribute(Qt::WA_TranslucentBackground);
    QFont f("serif");
    f.setItalic(true);
    f.setPointSize(35);
    f.setBold(true);
    start=new QPushButton("start", this);
    start->setFont(f);
    start->setGeometry(380,480+20,200,50);
    start->setStyleSheet(" QPushButton{  color : DarkRed; }");

    exit=new QPushButton("exit", this);
    exit->setFont(f);
    exit->setGeometry(380,480+126,200,50);
    exit->setStyleSheet(" QPushButton{  color : DarkGreen; }");


    QLabel *name = new QLabel("user name ",this);
    name->setStyleSheet(" QLabel{ background-color : DarkBlue; color : yellow; }");;
    name->setGeometry(750,10,80,20);



    userName = new QTextEdit(this);
    userName->setGeometry(850,10,100,20);
    userName->setStyleSheet(" QTextEdit{ background-color : DarkBlue; color : yellow; }");
    connect(userName,SIGNAL(textChanged()),this,SLOT(setUserName()));

    card=new QPushButton("cards", this);
    card->setFont(f);
    card->setGeometry(380,480+73,200,50);
    card->setStyleSheet(" QPushButton{  color : Darkblue; }");


    QLabel *notifL=new QLabel(this);
    notifL->setStyleSheet("QLabel { background-color : DarkBlue; color : yellow; }");
    notifL->setText("play mode :");
    notifL->setGeometry(750,40,80,30);
    notification= new QCheckBox("1-1" , this);
    notification->setGeometry(840 ,40 , 50, 30);
    notification->setStyleSheet("QTextEdit { background-color :DarkBlue; color : white; }");
    notification2 = new QCheckBox("2-2" , this);
    notification2->setGeometry(900 ,40 , 50, 30);
    notification2->setStyleSheet("QTextEdit { background-color : DarkBlue; color :yellow; }");



}


void menu ::setUserName() {
    m-> name = userName->toPlainText();



}