//
// Created by ghazal on 6/26/16.
//



#include <QWidget>
#include <QtWidgets>

#include <QStackedWidget>
#include <QtMultimedia/QMediaPlayer>
#include "manager.h"

#ifndef CLASH_CLIENT_STARTMENU_H
#define CLASH_CLIENT_STARTMENU_H

#endif //CLASH_CLIENT_STARTMENU_H
using namespace std;
class menu :public QWidget {
    Q_OBJECT
//Qobjecto chera minevisim?
public:
    QString name ;
    bool mode =true  ;
    menu(manager * x);
    void board();
    QTextEdit *userName;
    bool sh = true;
    QPushButton *start;
    QPushButton *card;

    QPushButton *exit;

    QCheckBox *notification;
    QCheckBox *notification2;
    manager *m ;

public slots:

    void setUserName();


};
