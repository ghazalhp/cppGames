//
// Created by ghazal on 6/27/16.
//

#include <iostream>
#include "using-furnace.h"

Furnace ::Furnace()  {

    name = "furnace";
    id = 13;
    hitSpeed = 5;
    deployTime = 1;
    range = 0;
    costEx = 5 ;
    hitPoints = 1536 ;
    damage = 0;
    life = hitPoints;
    myKind = tower;
    mySpeed = slow;
    myTargets = new vector<target* >;
    myTargets->push_back(new target (building));
    whoAmI = new target(building);
    myType = troop;
    nameOfPicture = "14.png";
    picture = new QIcon("14.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);
    lifeTime  = 0 ;





}
void Furnace ::move() {
    cout<<" move"<<name .toStdString() << endl;
    cout<<"lt"<<lifeTime<<endl;
    if(alive) {
        QString x;
        x.setNum(hitPoints);
        hitPointsButten->setPlainText(x);
        hitPointsButten->setPos(this->pos().x()-18,this->pos().y()-18);
        lifeTime++;
        mh = new FireSpirit *[2];
        for (int i = 0; i < 2; i++) {
            mh[i] = new FireSpirit();

            if (i < 1) {
                mh[i]->myPosition.x = this->myPosition.x - 30;
                mh[i]->myPosition.y = this->myPosition.y - 50;
            }
            else {
                mh[i]->myPosition.x = this->myPosition.x + 30;
                mh[i]->myPosition.y = this->myPosition.y - 50;
            }
            mh[i]->setPos(mh[i]->myPosition.x, mh[i]->myPosition.y);
            scene->addItem(mh[i]);
            mh[i]->hitPoints = mh[i]->life;
            mh[i]->alive = true;
            mh[i]->groupId = this->groupId;

            mh[i]->prepareToMove(t, allHero, scene);
        }
        if(lifeTime >= 5){
            lifeTime = 0 ;
            if(scene->items().contains(hitPointsButten))
                scene->removeItem(hitPointsButten);
            alive = false;
            scene->removeItem(this);
        }
    }

}