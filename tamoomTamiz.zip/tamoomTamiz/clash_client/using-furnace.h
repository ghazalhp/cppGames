//
// Created by ghazal on 6/27/16.
//

#ifndef CLASH_CLIENT_USING_FURNACE_H
#define CLASH_CLIENT_USING_FURNACE_H

#include "hero.h"
#include "fire-spirit.h"

class Furnace : public hero{
public:
        Furnace();

        FireSpirit ** mh ;

public slots:

    virtual void move();


};
#endif //CLASH_CLIENT_USING_FURNACE_H
