#include "valkyrie.h"

//
// Created by ghazal on 6/27/16.
//

//////////////////////////////
//////////////////////////////////
/////////////////////////////////////
//ino check kon etelataesho
Valkyrie ::Valkyrie()  {
    name = "valkyrie";
    id = 6;
    hitSpeed = 1.5;
    deployTime = 1;
    range = 0;
    costEx = 4 ;
    hitPoints = 880 ;
    damage = 120 ;
    life = hitPoints;
    mySpeed = medium;
    myType = troop;
    whoAmI = new target(ground);
    myTargets = new vector<target* >;
    myTargets->push_back(new target (ground));
    myTargets->push_back(new target (building));
    nameOfPicture = "7.png";
    picture = new QIcon("7.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);

}