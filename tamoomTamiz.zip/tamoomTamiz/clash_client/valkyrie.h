//
// Created by ghazal on 6/27/16.
//

#ifndef CLASH_CLIENT_VALKYRIE_H
#define CLASH_CLIENT_VALKYRIE_H

#include "hero.h"

class Valkyrie : public hero{
public:
    Valkyrie();

};

#endif //CLASH_CLIENT_VALKYRIE_H
