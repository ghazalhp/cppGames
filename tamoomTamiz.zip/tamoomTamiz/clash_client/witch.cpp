//
// Created by ghazal on 6/27/16.
//

#include <iostream>
#include "witch.h"
#include "skeleton.h"

Witch ::Witch()  {
    name = "witch";
    id = 7;
    hitSpeed = 0.7;
    deployTime = 1;
    range = 5.5;
    costEx = 5;
    hitPoints = 500 ;
    damage = 42 ;
    life = hitPoints;
    mySpeed = medium;
    myType = troop ;
    whoAmI = new target(ground);
    myTargets = new vector<target* >;
    myTargets->push_back(new target (air));
    myTargets->push_back(new target (ground));
    myTargets->push_back(new target (building));
    summons = 1;
    nameOfPicture = "8.png";
    picture = new QIcon("8.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);
     mh = new Skeleton *[3];

}

void Witch::prepareToMove(QTimer *timer1 , hero ** h , QGraphicsScene *s) {
    cout<<"prepare to mpve"<<name .toStdString() << endl;
    allHero = h ;
    scene = s ;
    //  t = timer ;
    hitPointsButten = new QGraphicsTextItem();
    hitPointsButten->setDefaultTextColor(Qt :: black);
        for(int i =0 ; i < 3 ; i ++){
            mh[i]= new Skeleton();

            if(i <  1) {
                mh[i]->myPosition.x = this->myPosition.x;
                mh[i]->myPosition.y = this->myPosition.y+(i*20) ;
            }
            else {
                mh[i]->myPosition.x = this->myPosition.x+50 ;
                mh[i]->myPosition.y = this->myPosition.y + ((i-2) * 20);
            }
            mh[i]->setPos(mh[i]->myPosition.x , mh[i]->myPosition.y);
            scene->addItem(mh[i]);
            mh[i]->hitPoints = mh[i]->life;
            mh[i]->alive = true;
            mh[i]->groupId = this->groupId ;

            mh[i]->prepareToMove(t, allHero, scene);
        }


    scene->addItem(hitPointsButten);
    cout<<"me"<< name.toStdString() <<  " " << myPosition.y <<  endl;
    deployT = 0 ;
    dpt = new QTimer();
    dpt->start(20);
    connect(dpt, SIGNAL(timeout()), this, SLOT(dT()));
}