//
// Created by ghazal on 6/27/16.
//

#ifndef CLASH_CLIENT_WITCH_H
#define CLASH_CLIENT_WITCH_H

#include "hero.h"
#include "skeleton.h"

class Witch : public hero{
public:
    Witch();
    virtual void prepareToMove(QTimer *timer  ,hero ** h ,QGraphicsScene *s);
    Skeleton ** mh ;

};
#endif //CLASH_CLIENT_WITCH_H
