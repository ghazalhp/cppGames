//
// Created by ghazal on 6/27/16.
//

#include <iostream>
#include "zap.h"

Zap ::Zap() {
    name = "zap";
    id = 11;

    range = 2.5;
    costEx = 2;
    hitPoints = 100;
    damage = 80 ;
    myTargets = new vector<target* >;
    myTargets->push_back(new target (building));
    myTargets->push_back(new target (air));
    myTargets->push_back(new target (ground));
    myType = spell;
    nameOfPicture = "12.png";
    picture = new QIcon("12.png");
    pixmap = new QPixmap();
    image = new QImage(nameOfPicture);
    pixmap->convertFromImage(image->scaled(40, 40));
    setPixmap(*pixmap);
    lifeTime = 0 ;
    victim = new QList<hero*>;
}

void Zap ::move() {

    if(!mode)
        size = 13 ;

    if(alive) {
        //cout<<"emm"<<endl;
        checkAlive();
        lifeTime++;

        for(int i = 0 ; i < scene->items().size() ;i++){
            if(dynamic_cast< hero*>(scene->items().at(i))!= 0) {
                hero *l = ( hero *) scene->items().at(i);
                if (l->groupId != this->groupId  && !victim->contains(l)) {
                    emergancy = true;
                    if (l->alive && scene->items().contains(l)) {


                            //            cout << "biaaa" << *myTargets->at(j2) << endl;

                        //              cout << "to if " << i << endl;
                        if ((range > 1 && sqrt((pow((myPosition.x - l->myPosition.x), 2) +
                                                (pow((myPosition.y - l->myPosition.y), 2)))) < range * 30) ||
                            (sqrt((pow((myPosition.x - l->myPosition.x), 2) +
                                   (pow((myPosition.y - l->myPosition.y), 2)))) < 50)) {

                            enemy = l;
                            victim->push_back(l);
                            killEnemy();
                        }



                        //          cout << "f for" << endl;
                    }
                }
            }
        }

        if(lifeTime >= 100){
            lifeTime = 0 ;
            alive = false;
            scene->removeItem(this);
        }
    }

}

void Zap ::killEnemy() {
    cout<<"enemy  "<< enemy->name.toStdString() << " " << enemy->myPosition.x << " "<<enemy->groupId << " me  " << name.toStdString()<<  " " << myPosition.x<< " " << groupId<<endl;
    enemy->hitPoints -= this->damage;
    if(enemy->hitPoints <=0 ){
        cout<<"AAAAA"<<endl;
        enemy->alive = false ;
        enemy->checkAlive();
        if(scene->items().contains(enemy))
            scene->removeItem(enemy);
        if(scene->items().contains(enemy->hitPointsButten))
            scene->removeItem(enemy->hitPointsButten);
        enemy = NULL;
    }else{
        enemy->deployT = 0 ;
        enemy->dpt->start(20);
        enemy->t->stop();
        enemy->connect(dpt, SIGNAL(timeout()), this, SLOT(dT()));
    }
}