//
// Created by ghazal on 6/27/16.
//

#ifndef CLASH_CLIENT_ZAP_H
#define CLASH_CLIENT_ZAP_H

#include "hero.h"

class Zap : public hero{
public:
    Zap();
    virtual void move();
    virtual  void killEnemy();
    QList<hero*>* victim ;

};

#endif //CLASH_CLIENT_ZAP_H
