

#include <iostream>
#include <server.h>
#include <QApplication>
using namespace std;

int main(int argc, char **argv) {
    QApplication app(argc,argv);
    cout << "Hello, World!" << endl;
    myServer *ms = new myServer("127.0.0.1");

    return app.exec();
}