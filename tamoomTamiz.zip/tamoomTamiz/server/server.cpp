//
// Created by ghazal on 4/10/16.
//

#include <server.h>
#include <QtNetwork/QTcpSocket>
#include <vector>
#include <QtNetwork/QTcpServer>
#include <iostream>
using  namespace std;
myServer ::myServer(QString x) {
    ip = x ;
    me =  new QTcpServer();
    ipForServer = QHostAddress(ip);
    me-> listen(ipForServer,listenPort);
    connect(me, SIGNAL(newConnection()),this, SLOT(postConnect()));
}
void myServer ::postConnect() {
    cout<< " postC" << endl;
    QTcpSocket *socket = me->nextPendingConnection();
    allClientSocket.push_back(socket);
    connect(socket,SIGNAL(readyRead()),this,SLOT(shareData()));
}

void myServer ::shareData() {
    cout<<"shareData"<<endl;
    QString reciveData ;
    for(int i = 0 ; i < allClientSocket.size() ; i++)
        if(allClientSocket[i]->bytesAvailable()){
            cout << " daram migiram"<< endl;
            reciveData = allClientSocket[i]->readAll();
  
        }
    cout << " ino gereftam "  << reciveData.toStdString() << endl;
    QByteArray sentData = &reciveData.toStdString()[0];
    for(int i = 0 ; i < allClientSocket.size() ; i++)
        allClientSocket[i]->write(sentData);


}
