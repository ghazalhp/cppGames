//
// Created by ghazal on 4/10/16.
//

#include <QtNetwork/QTcpSocket>
#include <vector>
#include <QtNetwork/QTcpServer>

#ifndef ANTIBARCAGRAM_SERVER_H
#define ANTIBARCAGRAM_SERVER_H
using  namespace std;
class myServer : public QObject {
    Q_OBJECT
public:
    myServer(QString s);


    QTcpServer  *me ;
    QString ip ;
    QHostAddress ipForServer;
    quint16 listenPort = 3000;
    vector<QTcpSocket *> allClientSocket ;
public slots:
    void postConnect();

    void shareData();
};

#endif //ANTIBARCAGRAM_SERVER_H
